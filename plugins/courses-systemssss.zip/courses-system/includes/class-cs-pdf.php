<?php
/**
 * Feature: Auto-Generated Course Outline PDF
 *
 * بيولّد ملف PDF أوتوماتيك لأي "Session" من بيانات الكورس نفسها
 * (نفس المحتوى اللي ظاهر في صفحة single-course.php) — من غير ما حد
 * يرفع PDF يدوي. الشكل مبني على نفس ستايل بروشور "Hufix HR Services".
 *
 * الاستخدام:
 *   الرابط: /?cs_pdf=SESSION_ID
 *   ( مربوط أوتوماتيك في زرار "Download Outline PDF" في templates/single-course.php )
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once CS_PATH . 'includes/lib/fpdf/fpdf.php';

/**
 * ------------------------------------------------------------------
 *  عدّل بيانات الشركة هنا لو اتغيرت.
 * ------------------------------------------------------------------
 */
if ( ! defined( 'CS_PDF_COMPANY_NAME' ) )    { define( 'CS_PDF_COMPANY_NAME', 'Hufix HR Services' ); }
if ( ! defined( 'CS_PDF_COMPANY_TAGLINE' ) ) { define( 'CS_PDF_COMPANY_TAGLINE', 'Professional Training & Development' ); }
if ( ! defined( 'CS_PDF_COMPANY_ADDRESS' ) ) { define( 'CS_PDF_COMPANY_ADDRESS', 'Hufix HR Services UG | Duesseldorf, Germany' ); }
if ( ! defined( 'CS_PDF_COMPANY_CONTACT' ) ) { define( 'CS_PDF_COMPANY_CONTACT', 'Tel: +49 1590 6453419 | Email: info@wedohr.net | Web: www.wedo-hr.de' ); }
if ( ! defined( 'CS_PDF_COMPANY_FOOTER' ) )  { define( 'CS_PDF_COMPANY_FOOTER', 'Your Strategic Partner in Professional Development' ); }

// ألوان البراند (نفس تيل الموقع).
if ( ! defined( 'CS_PDF_COLOR_TEAL_DARK' ) ) { define( 'CS_PDF_COLOR_TEAL_DARK', array( 22, 58, 63 ) ); }
if ( ! defined( 'CS_PDF_COLOR_TEAL' ) )      { define( 'CS_PDF_COLOR_TEAL', array( 80, 192, 175 ) ); }
if ( ! defined( 'CS_PDF_COLOR_GREY' ) )      { define( 'CS_PDF_COLOR_GREY', array( 110, 110, 110 ) ); }
if ( ! defined( 'CS_PDF_COLOR_LIGHT' ) )     { define( 'CS_PDF_COLOR_LIGHT', array( 244, 247, 246 ) ); }

class WeDo_Course_PDF extends FPDF {

	protected $company_name;

	public function __construct( $company_name ) {
		parent::__construct( 'P', 'mm', 'A4' );
		$this->company_name = $company_name;
		$this->SetMargins( 16, 12, 16 );
		$this->SetAutoPageBreak( true, 20 );
	}

	public function t( $text ) {
		// المحتوى ممكن يوصل من ووردبريس مع HTML entities زي &#038; أو &amp;
		// (مثلاً لو اسم الكورس فيه "&")، فبنفكّها الأول لحروفها الحقيقية...
		$text = html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' );
		// ...وبعدين نحوّل من UTF-8 لـ Windows-1252 عشان خطوط FPDF الأساسية بتشتغل بيه.
		return iconv( 'UTF-8', 'CP1252//TRANSLIT//IGNORE', $text );
	}

	public function up( $text ) {
		return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( (string) $text, 'UTF-8' ) : strtoupper( (string) $text );
	}

	public function Header() { // phpcs:ignore
		// شريط علوي غامق بنفس تيل الموقع، بيتكرر في كل صفحة.
		list( $r, $g, $b ) = CS_PDF_COLOR_TEAL_DARK;
		$this->SetFillColor( $r, $g, $b );
		$this->Rect( 0, 0, 210, 16, 'F' );
		$this->SetTextColor( 255, 255, 255 );
		$this->SetFont( 'Helvetica', 'B', 11 );
		$this->SetXY( 16, 4 );
		$this->Cell( 0, 8, $this->t( $this->company_name ), 0, 0, 'L' );
		$this->SetFont( 'Helvetica', '', 8 );
		$this->SetXY( -80, 5 );
		$this->Cell( 64, 6, $this->t( CS_PDF_COMPANY_TAGLINE ), 0, 0, 'R' );
		$this->SetY( 22 );
		$this->SetTextColor( 30, 30, 30 );
	}

	public function Footer() { // phpcs:ignore
		$this->SetY( -18 );
		list( $r, $g, $b ) = CS_PDF_COLOR_GREY;
		$this->SetDrawColor( $r, $g, $b );
		$this->Line( 16, $this->GetY(), 194, $this->GetY() );
		$this->SetY( -14 );
		$this->SetTextColor( $r, $g, $b );
		$this->SetFont( 'Helvetica', '', 7.5 );
		$this->Cell( 0, 5, $this->t( CS_PDF_COMPANY_ADDRESS . '   |   ' . CS_PDF_COMPANY_CONTACT ), 0, 1, 'C' );
		$this->SetFont( 'Helvetica', 'I', 7 );
		$this->Cell( 0, 4, $this->t( CS_PDF_COMPANY_FOOTER ), 0, 0, 'C' );
		$this->SetFont( 'Helvetica', '', 7.5 );
		$this->SetXY( -30, -14 );
		$this->Cell( 14, 5, 'Page ' . $this->PageNo(), 0, 0, 'R' );
	}

	/** عنوان قسم (Section heading) بستايل موحد. */
	public function section_title( $label ) {
		$this->Ln( 3 );
		list( $r, $g, $b ) = CS_PDF_COLOR_TEAL_DARK;
		$this->SetTextColor( $r, $g, $b );
		$this->SetFont( 'Helvetica', 'B', 12 );
		$this->Cell( 0, 8, $this->t( $this->up( $label ) ), 0, 1, 'L' );
		list( $tr, $tg, $tb ) = CS_PDF_COLOR_TEAL;
		$this->SetDrawColor( $tr, $tg, $tb );
		$this->SetLineWidth( 0.6 );
		$this->Line( $this->GetX(), $this->GetY(), $this->GetX() + 30, $this->GetY() );
		$this->SetLineWidth( 0.2 );
		$this->Ln( 4 );
		$this->SetTextColor( 30, 30, 30 );
	}

	/** بند بولت واحد. */
	public function bullet( $text, $indent = 0 ) {
		$this->SetFont( 'Helvetica', '', 10 );
		$x = $this->GetX() + $indent;
		$this->SetX( $x );
		$this->Cell( 5, 5.6, $this->t( '-' ), 0, 0 );
		$this->SetX( $x + 5 );
		$w = 178 - $indent;
		$this->MultiCell( $w, 5.6, $this->t( $text ) );
	}
}

class CS_PDF {

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_output' ) );
	}

	/**
	 * لو الرابط فيه ?cs_pdf=ID بنولّد الـ PDF ونطلعه ونوقف التنفيذ.
	 */
	public static function maybe_output() {
		if ( empty( $_GET['cs_pdf'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$session_id = absint( wp_unslash( $_GET['cs_pdf'] ) ); // phpcs:ignore WordPress.Security.NonceVerification

		if ( ! $session_id || get_post_type( $session_id ) !== CS_CPT || get_post_status( $session_id ) !== 'publish' ) {
			wp_die( esc_html__( 'Course not found.', 'courses-system' ), '', array( 'response' => 404 ) );
		}

		self::stream( $session_id );
		exit;
	}

	/**
	 * بيبني الـ PDF من نفس البيانات اللي بتتعرض في single-course.php ويطلعه للمتصفح.
	 */
	public static function stream( $session_id ) {

		$master_id = CS_CPT::master_id( $session_id );

		$country = get_post_meta( $session_id, CS_META_COUNTRY, true );
		$s_date  = get_post_meta( $session_id, CS_META_DATE, true );
		$s_end   = get_post_meta( $session_id, '_cs_session_end', true );
		$loc     = $country ? CS_Countries::name( $country ) : '';

		$title    = get_the_title( $master_id );
		$summary  = cs_field( 'cs_summary', $session_id );
		$mode     = CS_Listing::label_mode( cs_field( 'cs_delivery_mode', $session_id ) );
		$lang     = CS_Listing::label_lang( cs_field( 'cs_language', $session_id ) );
		$days     = cs_duration_days( $session_id );
		$hours    = (int) cs_field( 'cs_duration_hours', $session_id );
		$pc       = CS_Listing::country_price( $master_id, $country );
		$price    = $pc['price'];
		$curr     = $pc['currency'];
		$objs     = cs_field( 'cs_objectives', $session_id );
		$schedule = cs_field( 'cs_schedule', $session_id );

		$date_long = $s_date ? date_i18n( 'd F Y', strtotime( $s_date ) ) : '';
		$end_long  = $s_end ? date_i18n( 'd F Y', strtotime( $s_end ) ) : '';
		$date_disp = trim( $date_long . ( $end_long ? ' - ' . $end_long : '' ) );

		$pdf = new WeDo_Course_PDF( CS_PDF_COMPANY_NAME );
		$pdf->AliasNbPages();
		$pdf->AddPage();

		// عنوان الكورس.
		$pdf->SetFont( 'Helvetica', 'B', 18 );
		$pdf->SetTextColor( 20, 20, 20 );
		$pdf->MultiCell( 0, 8, $pdf->t( $title ) );
		$pdf->Ln( 2 );

		// شريط الـ Quick Facts (Duration / Delivery / Language / Dates / Investment).
		$facts = array(
			'Duration'   => $days ? ( $days . ' Days (' . $hours . ' Hours)' ) : '',
			'Delivery'   => $mode,
			'Language'   => $lang,
			'Dates'      => $date_disp,
			'Location'   => $loc,
			'Investment' => $curr ? trim( $curr . ' ' . ( $price ? number_format( (float) $price ) : '' ) ) : '',
		);
		$facts = array_filter( $facts );

		if ( $facts ) {
			$count = count( $facts );
			$colw  = 178 / $count;
			$y0    = $pdf->GetY();
			list( $lr, $lg, $lb ) = CS_PDF_COLOR_LIGHT;
			$pdf->SetFillColor( $lr, $lg, $lb );
			$pdf->Rect( 16, $y0, 178, 16, 'F' );
			$x = 16;
			foreach ( $facts as $label => $value ) {
				$pdf->SetXY( $x, $y0 + 2 );
				$pdf->SetFont( 'Helvetica', '', 7.5 );
				list( $gr, $gg, $gb ) = CS_PDF_COLOR_GREY;
				$pdf->SetTextColor( $gr, $gg, $gb );
				$pdf->Cell( $colw, 4, $pdf->t( $pdf->up( $label ) ), 0, 0, 'C' );
				$pdf->SetXY( $x, $y0 + 7 );
				$pdf->SetFont( 'Helvetica', 'B', 9 );
				$pdf->SetTextColor( 20, 20, 20 );
				$pdf->MultiCell( $colw, 4, $pdf->t( $value ), 0, 'C' );
				$x += $colw;
			}
			$pdf->SetY( $y0 + 20 );
		}

		// COURSE OVERVIEW.
		if ( $summary ) {
			$pdf->section_title( 'Course Overview' );
			$pdf->SetFont( 'Helvetica', '', 10 );
			$pdf->MultiCell( 0, 5.6, $pdf->t( $summary ) );
		}

		// LEARNING OBJECTIVES.
		if ( ! empty( $objs ) ) {
			$pdf->section_title( 'Learning Objectives' );
			foreach ( $objs as $o ) {
				if ( ! empty( $o['text'] ) ) {
					$pdf->bullet( $o['text'] );
				}
			}
		}

		// DETAILED COURSE OUTLINE (بنفس اليومية اللي في الصفحة).
		if ( ! empty( $schedule ) ) {
			$pdf->section_title( 'Detailed Course Outline' );
			$dn = 0;
			foreach ( $schedule as $day ) {
				$dn++;
				$day_title = ! empty( $day['day_title'] ) ? $day['day_title'] : ( 'Day ' . $dn );
				$pdf->SetFont( 'Helvetica', 'B', 10.5 );
				list( $tr, $tg, $tb ) = CS_PDF_COLOR_TEAL_DARK;
				$pdf->SetTextColor( $tr, $tg, $tb );
				$pdf->Ln( 1 );
				$pdf->Cell( 0, 6.5, $pdf->t( $day_title ), 0, 1 );
				$pdf->SetTextColor( 30, 30, 30 );
				if ( ! empty( $day['points'] ) ) {
					foreach ( $day['points'] as $p ) {
						if ( ! empty( $p['text'] ) ) {
							$pdf->bullet( $p['text'] );
						}
					}
				}
				$pdf->Ln( 1 );
			}
		}

		$filename = sanitize_title( $title ) . '-course-outline.pdf';

		// امسح أي auto-output اتحصل قبل كده عشان الـ PDF يطلع نضيف.
		if ( ! headers_sent() ) {
			while ( ob_get_level() ) {
				ob_end_clean();
			}
		}

		$pdf->Output( 'D', $filename );
	}
}

CS_PDF::init();