<?php
/**
 * Plugin Name: Courses System
 * Description: نظام كورسات متكامل (Master + Sessions) مع تكرار تلقائي، دول العالم، استيراد اكسيل، ودعم WPML.
 * Version:     1.2.0
 * Author:      Tasweqa
 * Text Domain: courses-system
 *
 * ملاحظة: لو بتنشر عن طريق Code Snippets، انسخ محتوى كل فايل في سنيبت منفصل
 * بنفس الترتيب اللي تحت. لو بتنشر كـ plugin، سيب الملفات زي ما هي.
 *
 * التحديثات في 1.1.0:
 *  - صورة الكورس (Featured Image): ترفعها يدوي من شاشة الكورس، أو من عمود
 *    image_url في شيت الاستيراد. بتتكرر تلقائي في كل السيشنز، ولو مفيش
 *    صورة الكارت بيتعرض عادي من غيرها (من غير صورة بديلة).
 *  - السعر وعدد الأيام بقوا مخفيين في وضع الكارت العادي (قبل ما تستخدم
 *    الفلتر)، زي الدولة والتاريخ بالظبط.
 *  - محرك التكرار بقى بيحسب مدة الكورس بأيام شغل بس (الاتنين للجمعة)،
 *    والسبت والأحد ملهومش وجود خالص لا في العد ولا لو وقع عليهم تاريخ البداية.
 *
 * التحديثات في 1.2.0:
 *  - اتشال حقل "Duration (days)" اليدوي خالص. عدد أيام الكورس بقى أوتوماتيك
 *    100% من نوع التكرار: كل أسبوع = 5 أيام، كل أسبوعين = 10 أيام.
 *  - اتضاف add_theme_support('post-thumbnails') عشان صندوق "Featured Image"
 *    يظهر في شاشة تعديل الكورس (بعض الثيمات مش بتفعّلها بنفسها).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// حارس: لو نسخة تانية من البلجن اتحمّلت قبل كده، بلاش نكرّر التحميل
// (بيمنع تكرار الـ constants وتكرار الكلاسات).
if ( defined( 'CS_VERSION' ) ) {
	return;
}

define( 'CS_VERSION', '1.0.0' );
define( 'CS_PATH', plugin_dir_path( __FILE__ ) );
define( 'CS_URL', plugin_dir_url( __FILE__ ) );

/**
 * ثوابت أساسية للسيستم كله عشان نبعد عن الـ magic strings.
 */
define( 'CS_CPT', 'course' );                 // البوست تايب
define( 'CS_TAX', 'course_category' );        // التاكسونومي (الكاتيجوري)
define( 'CS_META_IS_MASTER', '_cs_is_master' ); // 1 = ماستر كورس (قالب مخفي)
define( 'CS_META_MASTER', '_cs_master' );       // على السيشن: ID الماستر
define( 'CS_META_DATE', '_cs_session_date' );   // على السيشن: تاريخ البداية (Y-m-d)
define( 'CS_META_COUNTRY', '_cs_session_country' ); // على السيشن: كود الدولة

/**
 * تحميل فايلات الفيتشرز.
 * كل فايل = فيتشر واحدة بمسؤولية واحدة.
 */
$cs_files = array(
	'includes/class-cs-countries.php',   // بيانات دول العالم
	'includes/class-cs-cpt.php',         // تسجيل البوست تايب
	'includes/class-cs-taxonomy.php',    // تسجيل الكاتيجوري + صورة الكاتيجوري
	'includes/class-cs-acf.php',         // حقول ACF بالكود
	'includes/class-cs-recurrence.php',  // محرك التكرار + مزامنة + تجديد سنوي
	'includes/class-cs-slider.php',      // تحكم الإسلايدر
	'includes/class-cs-templates.php',   // تحميل تمبليتات الصفحات
	'includes/class-cs-assets.php',      // تحميل CSS/JS الثيم على صفحات الكورسات
	// الباقي هنضيفه في الخطوات الجاية:
	'includes/class-cs-listing.php',     // محرك عرض الكاتيجوري (عدم التكرار)
	'includes/class-cs-ajax.php',        // فلترة أجاكس
	'includes/class-cs-import.php',      // رفع الشيت (CSV Import)
	'includes/class-cs-wpml.php',        // ربط الترجمة مع WPML
	'includes/class-cs-pdf.php',         // توليد PDF أوتوماتيك من بيانات الكورس (بدون رفع يدوي)
);

foreach ( $cs_files as $cs_file ) {
	$path = CS_PATH . $cs_file;
	if ( file_exists( $path ) ) {
		require_once $path;
	}
}

/**
 * تفعيل / إلغاء التفعيل: نظّف الـ rewrite rules واجدول الكرون.
 */
register_activation_hook( __FILE__, function () {
	if ( class_exists( 'CS_CPT' ) ) {
		CS_CPT::register();
	}
	if ( class_exists( 'CS_Taxonomy' ) ) {
		CS_Taxonomy::register();
	}
	flush_rewrite_rules();

	// كرون يومي للتجديد السنوي وتنظيف السيشنز القديمة.
	if ( ! wp_next_scheduled( 'cs_daily_maintenance' ) ) {
		wp_schedule_event( time(), 'daily', 'cs_daily_maintenance' );
	}
} );

register_deactivation_hook( __FILE__, function () {
	flush_rewrite_rules();
	wp_clear_scheduled_hook( 'cs_daily_maintenance' );
} );


function cs_enqueue_assets() {

    wp_enqueue_script(
        'cs-filter',
        CS_URL . 'assets/js/cs-filter.js',
        array(),
        CS_VERSION,
        true
    );

    wp_localize_script(
        'cs-filter',
        'CS_FILTER',
        array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('cs_filter_nonce'),
        )
    );
}
add_action('wp_enqueue_scripts', 'cs_enqueue_assets');

