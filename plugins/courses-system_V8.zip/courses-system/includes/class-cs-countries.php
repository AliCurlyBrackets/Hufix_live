<?php
/**
 * Feature: Countries
 * مصدر واحد لدول العالم. أي فيتشر محتاجة الدول بتناديه من هنا بس.
 * الكود = ISO2، والاسم = اللي بيتعرض.
 *
 * الترجمة هنا بقت "Hardcoded" (مش عن طريق WPML String Translation):
 * كل دولة ليها اسم إنجليزي واسم عربي مكتوبين مباشرة في الكود، ودالة
 * name() بتختار الاسم المناسب أوتوماتيك حسب لغة الصفحة الحالية
 * (get_locale())، من غير أي خطوة إضافية في لوحة التحكم.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CS_Countries {

	/**
	 * كل الدول: code => name إنجليزي.
	 * ده اللي بيتغذّى منه اختيارات حقل الدولة في الأدمن (ACF)، فسيبناه
	 * إنجليزي زي ما هو عشان الأدمن يفضل شغال بشكل ثابت.
	 *
	 * @return array
	 */
	public static function all() {
		$list = array(
			'EG' => 'Egypt', 'SA' => 'Saudi Arabia', 'AE' => 'United Arab Emirates',
			'QA' => 'Qatar', 'KW' => 'Kuwait', 'BH' => 'Bahrain', 'OM' => 'Oman',
			'JO' => 'Jordan', 'LB' => 'Lebanon', 'IQ' => 'Iraq', 'SY' => 'Syria',
			'YE' => 'Yemen', 'PS' => 'Palestine', 'SD' => 'Sudan', 'LY' => 'Libya',
			'TN' => 'Tunisia', 'DZ' => 'Algeria', 'MA' => 'Morocco', 'MR' => 'Mauritania',
			'US' => 'United States', 'CA' => 'Canada', 'MX' => 'Mexico',
			'GB' => 'United Kingdom', 'IE' => 'Ireland', 'FR' => 'France',
			'DE' => 'Germany', 'IT' => 'Italy', 'ES' => 'Spain', 'PT' => 'Portugal',
			'NL' => 'Netherlands', 'BE' => 'Belgium', 'LU' => 'Luxembourg',
			'CH' => 'Switzerland', 'AT' => 'Austria', 'SE' => 'Sweden',
			'NO' => 'Norway', 'DK' => 'Denmark', 'FI' => 'Finland', 'IS' => 'Iceland',
			'PL' => 'Poland', 'CZ' => 'Czechia', 'SK' => 'Slovakia', 'HU' => 'Hungary',
			'RO' => 'Romania', 'BG' => 'Bulgaria', 'GR' => 'Greece', 'HR' => 'Croatia',
			'RS' => 'Serbia', 'UA' => 'Ukraine', 'RU' => 'Russia', 'TR' => 'Turkey',
			'CY' => 'Cyprus', 'MT' => 'Malta',
			'CN' => 'China', 'JP' => 'Japan', 'KR' => 'South Korea', 'IN' => 'India',
			'PK' => 'Pakistan', 'BD' => 'Bangladesh', 'ID' => 'Indonesia',
			'MY' => 'Malaysia', 'SG' => 'Singapore', 'TH' => 'Thailand',
			'VN' => 'Vietnam', 'PH' => 'Philippines', 'HK' => 'Hong Kong',
			'AU' => 'Australia', 'NZ' => 'New Zealand',
			'ZA' => 'South Africa', 'NG' => 'Nigeria', 'KE' => 'Kenya',
			'ET' => 'Ethiopia', 'GH' => 'Ghana', 'TZ' => 'Tanzania',
			'BR' => 'Brazil', 'AR' => 'Argentina', 'CL' => 'Chile',
			'CO' => 'Colombia', 'PE' => 'Peru',
		);

		/**
		 * فلتر عشان تقدر تضيف/تعدل الدول من غير ما تلمس الفايل ده.
		 */
		return apply_filters( 'cs_countries_list', $list );
	}

	/**
	 * نفس الدول بالظبط، بس بالاسم العربي. code => name عربي.
	 *
	 * @return array
	 */
	protected static function all_ar() {
		$list = array(
			'EG' => 'مصر', 'SA' => 'المملكة العربية السعودية', 'AE' => 'الإمارات العربية المتحدة',
			'QA' => 'قطر', 'KW' => 'الكويت', 'BH' => 'البحرين', 'OM' => 'عُمان',
			'JO' => 'الأردن', 'LB' => 'لبنان', 'IQ' => 'العراق', 'SY' => 'سوريا',
			'YE' => 'اليمن', 'PS' => 'فلسطين', 'SD' => 'السودان', 'LY' => 'ليبيا',
			'TN' => 'تونس', 'DZ' => 'الجزائر', 'MA' => 'المغرب', 'MR' => 'موريتانيا',
			'US' => 'الولايات المتحدة', 'CA' => 'كندا', 'MX' => 'المكسيك',
			'GB' => 'المملكة المتحدة', 'IE' => 'أيرلندا', 'FR' => 'فرنسا',
			'DE' => 'ألمانيا', 'IT' => 'إيطاليا', 'ES' => 'إسبانيا', 'PT' => 'البرتغال',
			'NL' => 'هولندا', 'BE' => 'بلجيكا', 'LU' => 'لوكسمبورغ',
			'CH' => 'سويسرا', 'AT' => 'النمسا', 'SE' => 'السويد',
			'NO' => 'النرويج', 'DK' => 'الدنمارك', 'FI' => 'فنلندا', 'IS' => 'آيسلندا',
			'PL' => 'بولندا', 'CZ' => 'التشيك', 'SK' => 'سلوفاكيا', 'HU' => 'المجر',
			'RO' => 'رومانيا', 'BG' => 'بلغاريا', 'GR' => 'اليونان', 'HR' => 'كرواتيا',
			'RS' => 'صربيا', 'UA' => 'أوكرانيا', 'RU' => 'روسيا', 'TR' => 'تركيا',
			'CY' => 'قبرص', 'MT' => 'مالطا',
			'CN' => 'الصين', 'JP' => 'اليابان', 'KR' => 'كوريا الجنوبية', 'IN' => 'الهند',
			'PK' => 'باكستان', 'BD' => 'بنغلاديش', 'ID' => 'إندونيسيا',
			'MY' => 'ماليزيا', 'SG' => 'سنغافورة', 'TH' => 'تايلاند',
			'VN' => 'فيتنام', 'PH' => 'الفلبين', 'HK' => 'هونغ كونغ',
			'AU' => 'أستراليا', 'NZ' => 'نيوزيلندا',
			'ZA' => 'جنوب أفريقيا', 'NG' => 'نيجيريا', 'KE' => 'كينيا',
			'ET' => 'إثيوبيا', 'GH' => 'غانا', 'TZ' => 'تنزانيا',
			'BR' => 'البرازيل', 'AR' => 'الأرجنتين', 'CL' => 'تشيلي',
			'CO' => 'كولومبيا', 'PE' => 'بيرو',
		);

		/** نفس منطق الفلتر بتاع اللستة الإنجليزية، بس للأسماء العربية. */
		return apply_filters( 'cs_countries_list_ar', $list );
	}

	/**
	 * اسم الدولة من الكود، بالإنجليزي أو العربي حسب لغة الصفحة الحالية.
	 * لو الكود مش موجود في اللستة، بيرجّع الكود نفسه زي ما هو.
	 */
	public static function name( $code ) {
		$all = self::all();

		if ( ! isset( $all[ $code ] ) ) {
			return $code;
		}

		$is_ar = ( strpos( get_locale(), 'ar' ) === 0 );

		if ( $is_ar ) {
			$ar = self::all_ar();
			if ( isset( $ar[ $code ] ) ) {
				return $ar[ $code ];
			}
		}

		return $all[ $code ];
	}

	/**
	 * تشيك إن الكود سليم.
	 */
	public static function exists( $code ) {
		return array_key_exists( strtoupper( $code ), self::all() );
	}

	/**
	 * تحويل قائمة أكواد (من الشيت مثلا "EG,SA,AE") لأكواد نضيفة صالحة.
	 */
	public static function sanitize_codes( $raw ) {
		if ( is_string( $raw ) ) {
			$raw = array_map( 'trim', explode( ',', $raw ) );
		}
		$out = array();
		foreach ( (array) $raw as $code ) {
			$code = strtoupper( trim( $code ) );
			if ( $code && self::exists( $code ) ) {
				$out[] = $code;
			}
		}
		return array_values( array_unique( $out ) );
	}
}