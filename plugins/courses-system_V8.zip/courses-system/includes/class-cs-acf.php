<?php
/**
 * Feature: ACF Fields (بالكود)
 * كل حقول صفحة السنجل كورس اتعملت هنا بالكود عشان تتنشر بـ Code Snippets
 * من غير ما تحتاج تعمل import/export لـ ACF JSON.
 *
 * الحقول دي كلها على الـ MASTER بس. السيشن بيقرأ منها.
 * أسماء الحقول (name) هي نفسها أعمدة الشيت -> شوف class-cs-import + الـ CSV.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'acf/init', 'cs_register_acf_fields' );

function cs_register_acf_fields() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	// خيارات الدول للـ select (بتتبني من فيتشر Countries).
	$country_choices = CS_Countries::all();

	// خيارات العملات.
	$currency_choices = array(
		'USD' => 'USD', 'EUR' => 'EUR', 'GBP' => 'GBP',
		'EGP' => 'EGP', 'SAR' => 'SAR', 'AED' => 'AED',
		'KWD' => 'KWD', 'QAR' => 'QAR', 'BHD' => 'BHD',
		'OMR' => 'OMR', 'JOD' => 'JOD',
	);

	acf_add_local_field_group( array(
		'key'      => 'group_cs_course',
		'title'    => 'Course Details',
		'fields'   => array(

			/* --- Hero / أساسي --- */
			array(
				'key'   => 'field_cs_summary',
				'label' => 'Summary (Hero description)',
				'name'  => 'cs_summary',
				'type'  => 'textarea',
				'rows'  => 3,
			),
			array(
				'key'     => 'field_cs_delivery_mode',
				'label'   => 'Delivery Mode',
				'name'    => 'cs_delivery_mode',
				'type'    => 'select',
				'choices' => array(
					'hybrid'    => 'Hybrid',
					'online'    => 'Online',
					'in_person' => 'In-Person',
				),
			),
			array(
				'key'     => 'field_cs_language',
				'label'   => 'Course Language',
				'name'    => 'cs_language',
				'type'    => 'select',
				'choices' => array(
					'english'   => 'English',
					'arabic'    => 'Arabic',
					'bilingual' => 'Bilingual',
				),
			),
			array(
				'key'   => 'field_cs_duration_hours',
				'label' => 'Duration (hours)',
				'name'  => 'cs_duration_hours',
				'type'  => 'number',
				'default_value' => 40,
			),

			/* --- الدول + السعر لكل دولة (بيغذّوا السيشنز والتسعير) --- */
			array(
				'key'          => 'field_cs_country_prices',
				'label'        => 'Countries & Prices',
				'name'         => 'cs_country_prices',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Add Country',
				'instructions' => 'كل صف = دولة الكورس هيتعمل فيها + سعرها + عملتها. السيشنز بتتولّد لكل دولة هنا.',
				'sub_fields'   => array(
					array(
						'key'     => 'field_cs_cp_country',
						'label'   => 'Country',
						'name'    => 'country',
						'type'    => 'select',
						'ui'      => 1,
						'choices' => $country_choices,
					),
					array(
						'key'   => 'field_cs_cp_price',
						'label' => 'Price',
						'name'  => 'price',
						'type'  => 'number',
					),
					array(
						'key'           => 'field_cs_cp_currency',
						'label'         => 'Currency',
						'name'          => 'currency',
						'type'          => 'select',
						'choices'       => $currency_choices,
						'default_value' => 'USD',
					),
				),
			),
			array(
				'key'   => 'field_cs_base_start_date',
				'label' => 'Base Start Date',
				'name'  => 'cs_base_start_date',
				'type'  => 'date_picker',
				'return_format' => 'Y-m-d',
				'instructions'  => 'تاريخ أول سيشن. لو فاضي، هياخد تاريخ النهاردة.',
			),
			array(
				'key'           => 'field_cs_recurrence',
				'label'         => 'Recurrence',
				'name'          => 'cs_recurrence',
				'type'          => 'radio',
				'choices'       => array(
					'weekly'   => 'كل أسبوع (5 أيام: الاتنين للجمعة)',
					'biweekly' => 'كل أسبوعين (10 أيام: أسبوعين شغل)',
				),
				'default_value' => 'weekly',
				'instructions'  => 'عدد أيام الكورس بيتحدد أوتوماتيك من هنا (السبت والأحد مالهومش وجود خالص) -- مفيش حاجة تانية تتكتب.',
			),

			/* --- Learning Objectives (repeater) --- */
			array(
				'key'        => 'field_cs_objectives',
				'label'      => 'Learning Objectives',
				'name'       => 'cs_objectives',
				'type'       => 'repeater',
				'layout'     => 'table',
				'button_label' => 'Add Objective',
				'sub_fields' => array(
					array(
						'key'   => 'field_cs_objective_text',
						'label' => 'Objective',
						'name'  => 'text',
						'type'  => 'text',
					),
				),
			),

			/* --- Daily Schedule (repeater جوه repeater) --- */
			array(
				'key'        => 'field_cs_schedule',
				'label'      => 'Daily Schedule',
				'name'       => 'cs_schedule',
				'type'       => 'repeater',
				'layout'     => 'block',
				'button_label' => 'Add Day',
				'sub_fields' => array(
					array(
						'key'   => 'field_cs_day_title',
						'label' => 'Day Title',
						'name'  => 'day_title',
						'type'  => 'text',
					),
					array(
						'key'        => 'field_cs_day_points',
						'label'      => 'Points',
						'name'       => 'points',
						'type'       => 'repeater',
						'layout'     => 'table',
						'button_label' => 'Add Point',
						'sub_fields' => array(
							array(
								'key'   => 'field_cs_day_point_text',
								'label' => 'Point',
								'name'  => 'text',
								'type'  => 'text',
							),
						),
					),
				),
			),

			/* --- Outline PDF --- */
			array(
				'key'          => 'field_cs_outline_pdf',
				'label'        => 'Course Outline PDF',
				'name'         => 'cs_outline_pdf',
				'type'         => 'file',
				'return_format' => 'url',
			),
		),

		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => CS_CPT,
				),
			),
		),
	) );
}