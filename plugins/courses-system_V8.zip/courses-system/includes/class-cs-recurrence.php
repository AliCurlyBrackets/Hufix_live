<?php
/**
 * Feature: Recurrence Engine
 * القلب بتاع السيستم. مسؤول عن:
 *   1) توليد الـ Sessions من الماستر: من تاريخ البداية -> آخر السنة،
 *      كل أسبوع/أسبوعين، مضروبة في عدد الدول المختارة.
 *   2) المزامنة: السيشن ما بيخزّنش محتوى، بيقرأ من الماستر ->
 *      فأي تعديل في الماستر بيظهر في كل السيشنز على طول (زي ما طلبت).
 *   3) التجديد السنوي: كرون يومي يولّد سيشنز السنة الجديدة وينضّف القديمة.
 *
 * مبدأ التصميم: السيشن = { master_id, date, country } بس. مفيش تكرار للمحتوى.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CS_Recurrence {

	public static function init() {
		// كل ما الماستر يتحفظ -> نعيد بناء السيشنز بتاعته.
		add_action( 'acf/save_post', array( __CLASS__, 'on_master_save' ), 20 );

		// كل ما الكاتيجوري (أو أي تاكسونومي) تتغيّر على بوست -> لو ده ماستر،
		// نفس التغيير ينزل على كل السيشنز بتاعته. ده بيغطي: تعديل عادي،
		// Quick Edit، وكمان Bulk Edit (اللي مش بيعدّي على acf/save_post أصلاً).
		add_action( 'set_object_terms', array( __CLASS__, 'sync_terms_to_sessions' ), 10, 6 );

		// الكرون اليومي: تجديد سنوي + تنظيف.
		add_action( 'cs_daily_maintenance', array( __CLASS__, 'daily_maintenance' ) );

		// لما الماستر يتمسح نهائي (Delete Permanently) -> امسح كل سيشناته معاه.
		add_action( 'before_delete_post', array( __CLASS__, 'on_master_delete' ) );
		// لما الماستر يتنقل للسلة (Trash) -> انقل سيشناته للسلة معاه.
		add_action( 'wp_trash_post', array( __CLASS__, 'on_master_trash' ) );
		// لو استرجعت الماستر من السلة -> استرجع سيشناته معاه.
		add_action( 'untrash_post', array( __CLASS__, 'on_master_untrash' ) );

		// إشعار تشخيصي في صفحة تعديل الكورس بعد الحفظ (مؤقت للتصحيح).
		add_action( 'admin_notices', array( __CLASS__, 'render_debug_notice' ) );
	}

	/**
	 * لما تاكسونومي (زي الكاتيجوري) تتغيّر على بوست كورس، وده ماستر (مش سيشن) ->
	 * نحط نفس الكاتيجوري على كل سيشنز الماستر ده. لو اللي اتغيّر سيشن (عنده
	 * CS_META_MASTER) منعملش حاجة، عشان منلفّش في حلقة لا نهائية.
	 *
	 * ملحوظة مهمة: مبنعتمدش على $tt_ids الجايين من الـ hook نفسه، لأنهم
	 * term_taxonomy_id (مش term_id) وممكن ييجوا كـ string مش int. لو اتبعتوا
	 * زي ما هما لـ wp_set_object_terms()، ووردبريس بيفتكرهم اسم كاتيجوري جديد
	 * وبينشئ كاتيجوري باسم الرقم نفسه (المشكلة اللي حصلت). فبدل كده، بنعيد جيب
	 * الـ term ids الحقيقية من الماستر بنفس الطريقة المضمونة المستخدمة في
	 * create_session().
	 *
	 * @param int    $object_id  ID البوست.
	 * @param string $taxonomy   اسم التاكسونومي.
	 */
	public static function sync_terms_to_sessions( $object_id, $terms, $tt_ids, $taxonomy ) {
		if ( CS_TAX !== $taxonomy || get_post_type( $object_id ) !== CS_CPT ) {
			return;
		}

		// ده سيشن مش ماستر -> بلاش نعيد النشر تاني.
		if ( get_post_meta( $object_id, CS_META_MASTER, true ) ) {
			return;
		}

		// term ids حقيقية للماستر (نفس الطريقة المستخدمة وقت إنشاء السيشن).
		$term_ids = wp_get_object_terms( $object_id, CS_TAX, array( 'fields' => 'ids' ) );
		if ( ! $term_ids || is_wp_error( $term_ids ) ) {
			$term_ids = array();
		}

		$sessions = get_posts( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_MASTER, 'value' => $object_id ),
			),
		) );

		foreach ( $sessions as $session_id ) {
			wp_set_object_terms( $session_id, $term_ids, CS_TAX );
		}
	}

	/**
	 * لما الماستر يتحفظ من لوحة التحكم.
	 */
	public static function on_master_save( $post_id ) {
		if ( get_post_type( $post_id ) !== CS_CPT ) {
			return;
		}
		// السيشنز ملهاش داعي تعيد توليد سيشنز.
		if ( CS_CPT::is_master( $post_id ) === false && get_post_meta( $post_id, CS_META_MASTER, true ) ) {
			return;
		}

		// أول ما نحفظ كورس من الأدمن، نعتبره ماستر.
		update_post_meta( $post_id, CS_META_IS_MASTER, 1 );

		// أي حفظ للماستر ممكن يكون غيّر تاريخ البداية أو نوع التكرار (أسبوع/أسبوعين)،
		// وده بيأثر على تاريخ و/أو مدة كل سيشن. لو سبنا generate_sessions() يشتغل لوحده
		// كان هيلاقي سيشن موجود بالفعل بنفس التاريخ القديم فيتخطاه (skipped_existing)
		// من غير ما يحدّث مدته/تاريخ نهايته -- ودي بالظبط المشكلة اللي كانت بتحصل
		// (تغيّر التكرار لأسبوعين وفعليًا السيشن فاضل بمدة الأسبوع القديمة). عشان
		// كده بنمسح كل سيشنز الماستر ده الأول، وبعدين نولّدها من الصفر بالقيم الجديدة.
		self::delete_sessions( $post_id );

		$result = self::generate_sessions( $post_id );
		set_transient( 'cs_gen_debug_' . $post_id, $result, 60 );
	}

	/**
	 * يمسح كل سيشنز ماستر معيّن (كل السنين)، نهائي. تُستخدم في حالتين:
	 *  1) قبل إعادة التوليد بعد أي حفظ للماستر (عشان مفيش سيشنز قديمة غلط فاضلة).
	 *  2) لما الماستر نفسه يتمسح نهائي -> نمسح سيشناته معاه.
	 *
	 * @param int $master_id
	 * @return int عدد السيشنز اللي اتمسحوا.
	 */
	public static function delete_sessions( $master_id ) {
		$sessions = get_posts( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_MASTER, 'value' => $master_id ),
			),
		) );
		foreach ( $sessions as $sid ) {
			wp_delete_post( $sid, true );
		}
		return count( $sessions );
	}

	/**
	 * لما بوست كورس يتمسح نهائي (Delete Permanently / force delete): لو ده ماستر،
	 * امسح كل سيشناته معاه نهائي. لو ده سيشن (عنده CS_META_MASTER) منعملش حاجة
	 * عشان منلفّش في حلقة، ولإن مسحه لوحده أصلاً حاجة عادية.
	 *
	 * @param int $post_id
	 */
	public static function on_master_delete( $post_id ) {
		if ( get_post_type( $post_id ) !== CS_CPT ) {
			return;
		}
		if ( get_post_meta( $post_id, CS_META_MASTER, true ) ) {
			return; // ده سيشن مش ماستر.
		}
		self::delete_sessions( $post_id );
	}

	/**
	 * لما الماستر ينقل للسلة (Trash)، ننقل كل سيشناته للسلة معاه.
	 *
	 * @param int $post_id
	 */
	public static function on_master_trash( $post_id ) {
		if ( get_post_type( $post_id ) !== CS_CPT ) {
			return;
		}
		if ( get_post_meta( $post_id, CS_META_MASTER, true ) ) {
			return; // ده سيشن مش ماستر.
		}
		$sessions = get_posts( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_MASTER, 'value' => $post_id ),
			),
		) );
		foreach ( $sessions as $sid ) {
			wp_trash_post( $sid );
		}
	}

	/**
	 * لو الماستر اتسترجع من السلة، نسترجع كل سيشناته اللي كانت اتنقلت معاه.
	 *
	 * @param int $post_id
	 */
	public static function on_master_untrash( $post_id ) {
		if ( get_post_type( $post_id ) !== CS_CPT ) {
			return;
		}
		if ( get_post_meta( $post_id, CS_META_MASTER, true ) ) {
			return; // ده سيشن مش ماستر.
		}
		$sessions = get_posts( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'trash',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_MASTER, 'value' => $post_id ),
			),
		) );
		foreach ( $sessions as $sid ) {
			wp_untrash_post( $sid );
		}
	}

	/**
	 * يعرض نتيجة التوليد كإشعار بعد الحفظ مباشرة (بيتشال لوحده بعد ما يتقرا مرة).
	 */
	public static function render_debug_notice() {
		global $pagenow;
		if ( 'post.php' !== $pagenow || empty( $_GET['post'] ) || empty( $_GET['message'] ) ) {
			return;
		}
		$post_id = (int) $_GET['post'];
		if ( get_post_type( $post_id ) !== CS_CPT ) {
			return;
		}
		$r = get_transient( 'cs_gen_debug_' . $post_id );
		if ( ! $r ) {
			return;
		}
		delete_transient( 'cs_gen_debug_' . $post_id );

		$class = $r['created'] > 0 ? 'notice-success' : 'notice-warning';
		echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p><strong>CS Sessions Debug:</strong> ';
		printf(
			'تم إنشاء <strong>%d</strong> سيشن جديد، وتخطّي %d موجودين مسبقًا. ',
			(int) $r['created'],
			(int) $r['skipped_existing']
		);
		if ( $r['used_fallback_no_country'] ) {
			echo '⚠️ مفيش دول اتقرت صح من حقل Countries &amp; Prices (اتحول لسيشن بدون دولة). ';
		}
		printf(
			'الدول اللي اتقرت: %s. من %s لحد %s، تكرار: %s.',
			esc_html( implode( ', ', array_filter( $r['countries_used'] ) ) ?: '(بدون دولة)' ),
			esc_html( $r['start_date'] ),
			esc_html( $r['year_end'] ),
			esc_html( $r['interval'] )
		);
		echo '</p></div>';
	}

	/**
	 * توليد/تحديث سيشنز ماستر معيّن للسنة الحالية.
	 * idempotent: لو السيشن موجود بنفس (تاريخ+دولة) مبيتعملش تاني.
	 *
	 * @param int      $master_id
	 * @param int|null $year      السنة (افتراضي: السنة الحالية).
	 */
	public static function generate_sessions( $master_id, $year = null ) {
		// تاريخ البداية الأول -- قبل ما نحدد السنة، عشان لو الكورس هيبدأ
		// في سنة جاية (زي 2027) نولّدله سيشنز فعلاً بدل ما نقف على "السنة
		// الحالية" ونطلع صفر نتايج.
		$base  = get_field( 'cs_base_start_date', $master_id );
		$start = $base ? strtotime( $base ) : current_time( 'timestamp' );

		// لو مفيش سنة اتفرضت من برا (زي الكرون)، خد سنة تاريخ البداية نفسه.
		$year = $year ? (int) $year : (int) gmdate( 'Y', $start );

		// الدول: من repeater الأسعار الأول، ولو فاضي من حقل cs_countries القديم.
		$countries = array();
		$rows = get_field( 'cs_country_prices', $master_id );
		if ( ! empty( $rows ) && is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				if ( ! empty( $row['country'] ) ) {
					$countries[] = $row['country'];
				}
			}
		}
		$raw_countries_count = count( $countries );
		if ( empty( $countries ) ) {
			$countries = (array) get_field( 'cs_countries', $master_id );
		}
		$countries_before_sanitize = $countries;
		$countries = CS_Countries::sanitize_codes( $countries );
		$used_fallback = false;
		if ( empty( $countries ) ) {
			// مفيش دول متسجلة/متعرّفة -> برضو نولّد سيشنز (بدون دولة محددة) عشان
			// الكورس يتكرر أسبوعي/كل أسبوعين زي المفروض ويظهر في الفرونت.
			$countries     = array( '' );
			$used_fallback = true;
		}

		$interval   = get_field( 'cs_recurrence', $master_id ) ?: 'weekly';
		$step_days  = ( 'biweekly' === $interval ) ? 14 : 7;
		// مدة الكورس بقت أوتوماتيك بالكامل من نوع التكرار -- مفيش حقل يدوي.
		// أسبوع = 5 أيام شغل (الاتنين للجمعة)، أسبوعين = 10 أيام شغل.
		$duration   = ( 'biweekly' === $interval ) ? 10 : 5;

		$year_start = strtotime( "$year-01-01" );
		$year_end   = strtotime( "$year-12-31" );
		if ( $start < $year_start ) {
			$start = $year_start;
		}

		// السبت والأحد مش أيام كورس خالص. لو تاريخ البداية وقع في الويكند
		// (يدوي أو بعد ما اتحدد بأول يناير)، حوّله لأول يوم شغل بعده (السبت).
		$start = self::next_business_day( $start );

		// نجيب السيشنز الموجودة عشان نعرف نبني اللي ناقص بس.
		$existing = self::existing_session_keys( $master_id, $year );

		$created = 0;
		$skipped_existing = 0;

		for ( $ts = $start; $ts <= $year_end; $ts = strtotime( "+{$step_days} days", $ts ) ) {
			$date = gmdate( 'Y-m-d', $ts );

			foreach ( $countries as $country ) {
				$key = $date . '|' . $country;
				if ( isset( $existing[ $key ] ) ) {
					$skipped_existing++;
					continue; // موجود بالفعل
				}
				$sid = self::create_session( $master_id, $date, $country, $duration );
				if ( $sid ) {
					$created++;
				}
			}
		}

		return array(
			'created'                    => $created,
			'skipped_existing'           => $skipped_existing,
			'countries_raw_repeater'     => $raw_countries_count,
			'countries_before_sanitize'  => $countries_before_sanitize,
			'countries_used'             => $countries,
			'used_fallback_no_country'   => $used_fallback,
			'start_date'                 => gmdate( 'Y-m-d', $start ),
			'year_end'                   => gmdate( 'Y-m-d', $year_end ),
			'interval'                   => $interval,
		);
	}

	/**
	 * إنشاء سيشن واحد (بوست خفيف بيشاور على الماستر).
	 */
	protected static function create_session( $master_id, $date, $country, $duration_days ) {
		$master = get_post( $master_id );
		if ( ! $master ) {
			return 0;
		}

		$session_id = wp_insert_post( array(
			'post_type'   => CS_CPT,
			'post_status' => 'publish',
			'post_title'  => $master->post_title, // للعرض في الأدمن بس
			'post_parent' => $master_id,
		) );

		if ( is_wp_error( $session_id ) || ! $session_id ) {
			return 0;
		}

		update_post_meta( $session_id, CS_META_MASTER, $master_id );
		update_post_meta( $session_id, CS_META_DATE, $date );
		update_post_meta( $session_id, CS_META_COUNTRY, $country );

		// تاريخ النهاية = المدة بأيام شغل بس (السبت والأحد ملهومش وجود في العد).
		// يعني أسبوع (5 أيام) = الاتنين لحد الجمعة، وأسبوعين (10 أيام) = بترجع
		// جمعة الأسبوع اللي بعده، من غير ما تتحسب أي سبت أو حد في نص الطريق.
		$end = gmdate( 'Y-m-d', self::business_day_end( strtotime( $date ), $duration_days ) );
		update_post_meta( $session_id, '_cs_session_end', $end );

		// السيشن ياخد نفس كاتيجوري الماستر.
		$terms = wp_get_object_terms( $master_id, CS_TAX, array( 'fields' => 'ids' ) );
		if ( $terms && ! is_wp_error( $terms ) ) {
			wp_set_object_terms( $session_id, $terms, CS_TAX );
		}

		return $session_id;
	}

	/**
	 * السبت (6) والأحد (7) مش أيام كورس. لو التاريخ وقع في واحد منهم،
	 * رجّع أول يوم شغل جاي (السبت -> الاتنين اللي بعده، الأحد -> الاتنين).
	 *
	 * @param int $ts Unix timestamp.
	 * @return int
	 */
	protected static function next_business_day( $ts ) {
		$dow = (int) gmdate( 'N', $ts ); // 1=Mon ... 6=Sat, 7=Sun
		if ( 6 === $dow ) {
			$ts = strtotime( '+2 days', $ts );
		} elseif ( 7 === $dow ) {
			$ts = strtotime( '+1 day', $ts );
		}
		return $ts;
	}

	/**
	 * يحسب آخر يوم كورس بعد ما يعدّ $duration_days من أيام الشغل بس، بادئًا
	 * بيوم البداية نفسه كـ "يوم 1". أي سبت/أحد بيتخطّاه تمامًا ومش بيتحسب
	 * ضمن الـ duration ولا بيوقّف عنده الكورس.
	 * مثال: بداية الاتنين + duration=5  -> الجمعة (نفس الأسبوع).
	 *       بداية الاتنين + duration=10 -> الجمعة اللي بعد أسبوع (مش بينها سبت/حد).
	 *
	 * @param int $start_ts      Unix timestamp ليوم البداية (المفروض يوم شغل بالفعل).
	 * @param int $duration_days عدد أيام الكورس الفعلية (شغل بس).
	 * @return int Unix timestamp لآخر يوم.
	 */
	protected static function business_day_end( $start_ts, $duration_days ) {
		$duration_days = max( 1, (int) $duration_days );
		$ts    = self::next_business_day( $start_ts ); // احتياطًا لو جالنا تاريخ ويكند.
		$count = 1; // يوم البداية = يوم شغل رقم 1.

		while ( $count < $duration_days ) {
			$ts  = strtotime( '+1 day', $ts );
			$dow = (int) gmdate( 'N', $ts );
			if ( $dow < 6 ) { // مش سبت ولا حد.
				$count++;
			}
		}

		return $ts;
	}

	/**
	 * مفاتيح السيشنز الموجودة (date|country) لماستر في سنة.
	 */
	protected static function existing_session_keys( $master_id, $year ) {
		$q = new WP_Query( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_MASTER, 'value' => $master_id ),
				array(
					'key'     => CS_META_DATE,
					'value'   => array( "$year-01-01", "$year-12-31" ),
					'compare' => 'BETWEEN',
					'type'    => 'DATE',
				),
			),
		) );

		$keys = array();
		foreach ( $q->posts as $sid ) {
			$date    = get_post_meta( $sid, CS_META_DATE, true );
			$country = get_post_meta( $sid, CS_META_COUNTRY, true );
			$keys[ $date . '|' . $country ] = $sid;
		}
		return $keys;
	}

	/* ===================== Sync ===================== */
	// ملاحظة: مفيش داعي لكود مزامنة معقّد. لإن السيشن بيقرأ المحتوى من الماستر
	// وقت العرض (شوف cs_field() تحت)، فأي تعديل في الماستر بيبان في كل السيشنز
	// فورًا. الحاجة الوحيدة اللي بتتغير لما تعدّل الدول/التكرار هي عدد السيشنز،
	// وده on_master_save بيتكفّل بيه.

	/**
	 * Helper عام: هات قيمة حقل بغض النظر إنت واقف على سيشن ولا ماستر.
	 * أي template بتستخدمه عشان "التعديل يبان في الكوبي".
	 */
	public static function field( $name, $post_id = null ) {
		$post_id   = $post_id ?: get_the_ID();
		$master_id = CS_CPT::master_id( $post_id );
		return get_field( $name, $master_id );
	}

	/**
	 * عدد أيام الكورس -- أوتوماتيك بالكامل من نوع التكرار، مفيش حقل يدوي:
	 * كل أسبوع = 5 أيام شغل (الاتنين للجمعة)، كل أسبوعين = 10 أيام شغل.
	 * بتشتغل صح سواء انت واقف على ماستر أو سيشن.
	 */
	public static function duration_days( $post_id = null ) {
		$post_id   = $post_id ?: get_the_ID();
		$master_id = CS_CPT::master_id( $post_id );
		$interval  = get_field( 'cs_recurrence', $master_id ) ?: 'weekly';
		return ( 'biweekly' === $interval ) ? 10 : 5;
	}

	/* ================= Yearly Renewal ================= */

	/**
	 * كرون يومي:
	 *  - يحذف السيشنز اللي عدّى تاريخها (تنظيف).
	 *  - في بداية كل سنة (أو لو ناقص) يولّد سيشنز السنة الحالية لكل الماسترز.
	 */
	public static function daily_maintenance() {
		$today = current_time( 'Y-m-d' );
		$year  = (int) current_time( 'Y' );

		// 1) تنظيف السيشنز القديمة.
		$old = new WP_Query( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_MASTER, 'compare' => 'EXISTS' ),
				array( 'key' => '_cs_session_end', 'value' => $today, 'compare' => '<', 'type' => 'DATE' ),
			),
		) );
		foreach ( $old->posts as $sid ) {
			wp_delete_post( $sid, true );
		}

		// 2) ضمان سيشنز السنة الحالية لكل الماسترز.
		$masters = new WP_Query( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_IS_MASTER, 'value' => 1 ),
			),
		) );
		foreach ( $masters->posts as $master_id ) {
			self::generate_sessions( $master_id, $year );
		}
	}
}

CS_Recurrence::init();

/**
 * Wrapper قصير تستخدمه في الـ templates بدل get_field.
 * بيضمن إن السيشن بيقرأ محتوى الماستر.
 */
function cs_field( $name, $post_id = null ) {
	return CS_Recurrence::field( $name, $post_id );
}

/**
 * عدد أيام الكورس (أوتوماتيك من نوع التكرار -- weekly=5 / biweekly=10).
 * استخدمها بدل get_field('cs_duration_days', ...) في أي مكان.
 */
function cs_duration_days( $post_id = null ) {
	return CS_Recurrence::duration_days( $post_id );
}