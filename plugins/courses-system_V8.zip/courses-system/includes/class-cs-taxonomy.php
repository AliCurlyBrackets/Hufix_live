<?php
/**
 * Feature: Course Category (Taxonomy) + Category Image
 * الكاتيجوري باسم + صورة. الصورة بتتخزن كـ term meta (attachment ID).
 * صفحة عرض الكاتيجوريز بتقرأ الاسم + الصورة من هنا.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CS_Taxonomy {

	const IMG_META = 'cs_category_image';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );

		// حقل صورة في صفحة إضافة/تعديل الكاتيجوري.
		add_action( CS_TAX . '_add_form_fields', array( __CLASS__, 'add_field' ) );
		add_action( CS_TAX . '_edit_form_fields', array( __CLASS__, 'edit_field' ), 10, 2 );
		add_action( 'created_' . CS_TAX, array( __CLASS__, 'save_field' ) );
		add_action( 'edited_' . CS_TAX, array( __CLASS__, 'save_field' ) );

		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'media_scripts' ) );
	}

	public static function register() {
		$labels = array(
			'name'          => 'Course Categories',
			'singular_name' => 'Category',
			'menu_name'     => 'Categories',
			'add_new_item'  => 'Add New Category',
		);

		register_taxonomy( CS_TAX, CS_CPT, array(
			'labels'            => $labels,
			'public'            => true,
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'course-category' ),
		) );
	}

	/** رابط صورة الكاتيجوري (لاستخدامه في صفحة العرض). */
	public static function image_url( $term_id, $size = 'medium' ) {
		$attachment_id = (int) get_term_meta( $term_id, self::IMG_META, true );
		if ( ! $attachment_id ) {
			return '';
		}
		return wp_get_attachment_image_url( $attachment_id, $size );
	}

	/* ================= Admin UI ================= */

	public static function media_scripts( $hook ) {
		if ( strpos( $hook, 'edit-tags' ) !== false || strpos( $hook, 'term' ) !== false ) {
			wp_enqueue_media();
		}
	}

	public static function add_field() {
		?>
		<div class="form-field">
			<label>Category Image</label>
			<input type="hidden" name="cs_category_image" id="cs_category_image" value="">
			<button type="button" class="button cs-upload-img">Choose Image</button>
			<div id="cs_category_image_preview" style="margin-top:8px"></div>
		</div>
		<?php self::inline_js();
	}

	public static function edit_field( $term ) {
		$attachment_id = (int) get_term_meta( $term->term_id, self::IMG_META, true );
		$url           = $attachment_id ? wp_get_attachment_image_url( $attachment_id, 'thumbnail' ) : '';
		?>
		<tr class="form-field">
			<th><label>Category Image</label></th>
			<td>
				<input type="hidden" name="cs_category_image" id="cs_category_image" value="<?php echo esc_attr( $attachment_id ); ?>">
				<button type="button" class="button cs-upload-img">Choose Image</button>
				<div id="cs_category_image_preview" style="margin-top:8px">
					<?php if ( $url ) : ?><img src="<?php echo esc_url( $url ); ?>" style="max-width:120px"><?php endif; ?>
				</div>
			</td>
		</tr>
		<?php self::inline_js();
	}

	public static function save_field( $term_id ) {
		if ( isset( $_POST['cs_category_image'] ) ) {
			update_term_meta( $term_id, self::IMG_META, absint( $_POST['cs_category_image'] ) );
		}
	}

	protected static function inline_js() {
		?>
		<script>
		jQuery(function($){
			$(document).on('click', '.cs-upload-img', function(e){
				e.preventDefault();
				var frame = wp.media({ title:'Select Image', multiple:false });
				frame.on('select', function(){
					var a = frame.state().get('selection').first().toJSON();
					$('#cs_category_image').val(a.id);
					$('#cs_category_image_preview').html('<img src="'+a.url+'" style="max-width:120px">');
				});
				frame.open();
			});
		});
		</script>
		<?php
	}
}

CS_Taxonomy::init();