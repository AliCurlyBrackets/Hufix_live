<?php
/**
 * Feature: WPML Linking
 * مسؤول عن حاجة واحدة بس: تحديد لغة بوست معيّن، وربطه كترجمة لبوست تاني
 * (بنفس trid) باستخدام الـ API الرسمي بتاع WPML. مبيعملش أي ترجمة نصوص
 * فعلية -- ده شغل الأدمن (بيكتب النص العربي في الشيت)، إحنا بس بنربط.
 *
 * محتاج WPML Multilingual CMS شغّال وميظبطش عليه.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CS_WPML {

	/**
	 * عدد السيشنز اللي بتتربط في كل دفعة (batch). كورسات فيها أماكن كتير
	 * (زي 50 مكان) بتولّد مئات السيشنز، ولو حاولنا نربطهم كلهم مرة واحدة
	 * جوه نفس الريكوست اللي بيرفع الشيت، بيحصل زحمة استعلامات ضخمة
	 * (خصوصًا إن WPML نفسه بيعمل استعلامات إضافية في shutdown hook لكل
	 * بوست اتلمس) وده بيسبب صفحة بيضا (timeout أو desync مع الداتابيز).
	 * عشان كده الربط بقى بيحصل بالخلفية عبر WP-Cron على دفعات صغيرة
	 * بدل ما يحصل كله فورًا في نفس الريكوست.
	 */
	const SESSIONS_BATCH_SIZE = 25;

	/** الوقت بالثواني بين كل دفعة والتانية. */
	const BATCH_INTERVAL = 10;

	public static function init() {
		add_action( 'cs_tag_sessions_language_batch', array( __CLASS__, 'tag_sessions_language_batch' ), 10, 4 );

		// لازم نستنى لحد ما كل سيشنز الماستر تخلص توليد (ممكن يحصل في
		// الخلفية على دفعات دلوقتي -- شوف CS_Recurrence::queue_remaining_sessions())
		// قبل ما نبدأ نربطهم كترجمات. لو ربطنا بدري (زي الأول لما كان
		// التاجينج بينادى فورًا بعد generate_sessions())، أي سيشن لسه
		// هيتعمل بعد كده في دفعة تالية كان بيفوت الربط تمامًا (تاجينج
		// batch بتوقف أول ما تلاقي صفحة فيها أقل من SESSIONS_BATCH_SIZE،
		// وممكن تكون دي "آخر صفحة موجودة دلوقتي" مش آخر صفحة فعلاً).
		add_action( 'cs_sessions_generation_done', array( __CLASS__, 'maybe_tag_after_generation' ) );
	}

	/**
	 * بتشتغل تلقائي أول ما كل سيشنز ماستر معيّن تخلص توليد بالكامل. لو
	 * الماستر ده متعلّم من CS_Import إنه محتاج ربط لغة/ترجمة (عمود lang
	 * أو source_course_id في الشيت)، بيحصل الربط دلوقتي بس -- بعد ما نتأكد
	 * إن كل سيشناته موجودة فعلاً. لو الماستر ده مش جايه من استيراد
	 * (زي حفظ يدوي عادي أو كرون التجديد السنوي)، الدالة بترجع فورًا من
	 * غير أي تأثير.
	 *
	 * @param int $master_id
	 */
	public static function maybe_tag_after_generation( $master_id ) {
		if ( ! self::active() ) {
			return;
		}

		$lang_code = get_post_meta( $master_id, '_cs_pending_wpml_lang', true );
		if ( ! $lang_code ) {
			return;
		}

		$source_id = (int) get_post_meta( $master_id, '_cs_pending_wpml_source', true );

		// لغة الماستر نفسه اتحددت فورًا وقت الاستيراد (شوف
		// CS_Import::import_row())، مش هنا -- هنا بس بنربط كل سيشن
		// اتولد فعلاً بالسيشن الإنجليزي المقابل له (نفس التاريخ + الدولة).
		self::tag_sessions_language( $master_id, $lang_code, $source_id );

		delete_post_meta( $master_id, '_cs_pending_wpml_lang' );
		delete_post_meta( $master_id, '_cs_pending_wpml_source' );
	}

	/** هل WPML شغّال فعلاً على الموقع؟ */
	public static function active() {
		return defined( 'ICL_SITEPRESS_VERSION' ) || class_exists( 'SitePress' );
	}

	/** كود اللغة الافتراضي للموقع (مثلاً "en"). */
	public static function default_language() {
		$lang = apply_filters( 'wpml_default_language', null );
		return $lang ? $lang : 'en';
	}

	/**
	 * حدّد لغة بوست. لو مش متحدد له trid قبل كده، هيتعمله واحد جديد تلقائي.
	 *
	 * @param int    $post_id
	 * @param string $lang_code كود اللغة زي "en" أو "ar"
	 */
	public static function set_language( $post_id, $lang_code ) {
		if ( ! self::active() ) {
			return;
		}

		$element_type = 'post_' . CS_CPT;
		$trid         = apply_filters( 'wpml_element_trid', null, $post_id, $element_type );

		do_action( 'wpml_set_element_language_details', array(
			'element_id'           => $post_id,
			'element_type'         => $element_type,
			'trid'                 => $trid, // null = هيتعمله trid جديد.
			'language_code'        => $lang_code,
			'source_language_code' => null,
		) );
	}

	/**
	 * اربط $post_id كترجمة لـ $source_id بلغة $lang_code.
	 * لو $source_id لسه مالوش لغة متحددة، هيتحط في اللغة الافتراضية للموقع الأول.
	 *
	 * @return bool نجح الربط ولا لأ
	 */
	public static function link_translation( $post_id, $source_id, $lang_code ) {
		if ( ! self::active() ) {
			return false;
		}
		if ( ! $post_id || ! $source_id || $post_id === $source_id ) {
			return false;
		}
		if ( get_post_type( $source_id ) !== CS_CPT ) {
			return false;
		}

		$element_type = 'post_' . CS_CPT;

		// تأكد إن الأصل نفسه متحدد له لغة (مهم عشان الـ trid يتظبط صح).
		$source_lang = apply_filters( 'wpml_element_language_code', null, array(
			'element_id'   => $source_id,
			'element_type' => $element_type,
		) );

		if ( ! $source_lang ) {
			$source_lang = self::default_language();
			self::set_language( $source_id, $source_lang );
		}

		$trid = apply_filters( 'wpml_element_trid', null, $source_id, $element_type );

		do_action( 'wpml_set_element_language_details', array(
			'element_id'           => $post_id,
			'element_type'         => $element_type,
			'trid'                 => $trid,
			'language_code'        => $lang_code,
			'source_language_code' => $source_lang,
		) );

		return true;
	}

	/**
	 * استنسخ كل حقول ACF البسيطة (المواعيد، الدول، الأسعار، المدة...) من
	 * كورس أصلي لكورس تاني. بنستخدمها قبل ما نطبّق أعمدة الشيت المترجمة،
	 * عشان الكورس العربي "يدابلكيت" هيكل الأصلي بالظبط (نفس التواريخ والدول)
	 * وبعدين بس نستبدل النصوص بالترجمة اللي في الصف.
	 */
	public static function clone_master_fields( $source_id, $target_id ) {
		$fields = array(
			'cs_summary',
			'cs_delivery_mode',
			'cs_language',
			'cs_duration_hours',
			'cs_country_prices',
			'cs_base_start_date',
			'cs_recurrence',
			'cs_objectives',
			'cs_schedule',
			'cs_outline_pdf',
		);

		foreach ( $fields as $field ) {
			$value = get_field( $field, $source_id );
			if ( null !== $value && '' !== $value ) {
				update_field( $field, $value, $target_id );
			}
		}

		// نفس الكاتيجوري (لو الصف مادّاش category مختلفة، هيتستبدل بعدين لو موجودة).
		$terms = wp_get_object_terms( $source_id, CS_TAX, array( 'fields' => 'ids' ) );
		if ( $terms && ! is_wp_error( $terms ) ) {
			wp_set_object_terms( $target_id, $terms, CS_TAX );
		}
	}

	/**
	 * حط نفس لغة الماستر على كل السيشنز بتاعته (عشان WPML يفلتر صح
	 * في الفرونت حسب لغة الموقع الحالية). لو الماستر ده أصلاً ترجمة لماستر
	 * تاني ($source_master_id)، كل سيشن عربي (مثلاً) بيتربط كـ "ترجمة" فعلية
	 * للسيشن الإنجليزي المقابل له (نفس التاريخ + نفس الدولة)، مش بس بيتحط
	 * له لغة لوحده من غير ربط. من غير الربط ده، WPML بيعتبر السيشنز
	 * المترجمة بوستات "يتيمة" (مالهاش أصل)، وغالبًا بيستبعدها من العرض/الفلاتر
	 * زي ما ظهر لما اتعمل import لشيت عربي (اتترجم الماستر بس، من غير سيشناته).
	 *
	 * @param int    $master_id        ID الماستر (المترجَم، مثلاً العربي).
	 * @param string $lang_code        كود لغة الماستر ده.
	 * @param int    $source_master_id (اختياري) ID الماستر الأصلي لو ده ترجمة له.
	 */
	public static function tag_sessions_language( $master_id, $lang_code, $source_master_id = 0 ) {
		if ( ! self::active() ) {
			return;
		}

		// كورسات فيها كذا مكان بيبقى عندها كذا سيشن (مكان × تكرار)، فمنعملش
		// الربط كله دلوقتي جوه نفس الريكوست -- بنجدول أول دفعة بس، والباقي
		// هيكمّل نفسه لوحده كل دفعة بتجدول اللي بعدها (شوف
		// tag_sessions_language_batch()). ده بيخلي رفع الشيت يرجع بسرعة
		// حتى لو الكورس عنده مئات السيشنز.
		self::schedule_sessions_batch( $master_id, $lang_code, $source_master_id, 0 );
	}

	/**
	 * جدوَل دفعة ربط سيشنز واحدة (عبر WP-Cron) تبدأ من $offset.
	 */
	protected static function schedule_sessions_batch( $master_id, $lang_code, $source_master_id, $offset ) {
		wp_schedule_single_event(
			time() + self::BATCH_INTERVAL,
			'cs_tag_sessions_language_batch',
			array( $master_id, $lang_code, $source_master_id, $offset )
		);

		// لو مفيش زوار على الموقع دلوقتي، الـ cron العادي ممكن ياخد وقت
		// لحد ما يتفعّل. الدالة دي (بتاعة ووردبريس نفسه) بتبعت طلب HTTP
		// غير مانع (non-blocking) لـ wp-cron.php فورًا عشان الدفعة تتنفذ
		// بسرعة من غير ما نستنى زيارة حقيقية للموقع.
		if ( function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}
	}

	/**
	 * بتشتغل من WP-Cron. بتربط دفعة واحدة بس (SESSIONS_BATCH_SIZE سيشن)
	 * من سيشنز $master_id، وبعدين -- لو لسه فاضل سيشنز -- بتجدول
	 * الدفعة اللي بعدها. كل دفعة ريكوست/عملية منفصلة تمامًا عن اللي
	 * رفع بيها الأدمن الشيت، فمستحيل تسبب صفحة بيضا للأدمن.
	 *
	 * @param int    $master_id
	 * @param string $lang_code
	 * @param int    $source_master_id
	 * @param int    $offset            كام سيشن اتربطوا لحد دلوقتي (بنكمل منه).
	 */
	public static function tag_sessions_language_batch( $master_id, $lang_code, $source_master_id, $offset ) {
		if ( ! self::active() ) {
			return;
		}

		$sessions = get_posts( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => self::SESSIONS_BATCH_SIZE,
			'offset'         => (int) $offset,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
			'meta_key'       => CS_META_MASTER,
			'meta_value'     => $master_id,
		) );

		if ( empty( $sessions ) ) {
			// خلصنا كل السيشنز -- نضّف الكاش المؤقت بتاع فهرس السيشنز الأصلية.
			if ( $source_master_id ) {
				delete_transient( 'cs_src_sessions_' . $source_master_id );
			}
			return;
		}

		// فهرس سيشنز الماستر الأصلي، متخزّن مؤقتًا (transient) عشان منعيدش
		// نجيبه من الداتابيز في كل دفعة -- كورس فيه 250 سيشن يعني 10 دفعات،
		// مفيش داعي نكرر نفس الاستعلام الكبير 10 مرات.
		//
		// ⚠️ بنبني فهرسين مش واحد:
		// - $by_loc_index: المفتاح "date|loc_index" (رقم ترتيب المكان جوه
		//   repeater الأسعار، شوف CS_META_LOC_INDEX). ده المطابقة الصح
		//   والموثوقة، لإنه مش متأثر بترجمة اسم المكان.
		// - $by_country: المفتاح القديم "date|country" (نص المكان الحرفي)،
		//   احتياطي بس لسيشنز اتعملت قبل ما CS_META_LOC_INDEX يتضاف
		//   (مالهاش القيمة دي، فبيرجعوا بـ loc_index = 0 لكل السيشنز، وده
		//   مش موثوق -- فبنفضّل نطابق بيه بس لو المطابقة بالـ loc_index فشلت).
		//
		// ليه المطابقة بنص المكان (زي ما كانت قبل كده) مش كافية لوحدها: المكان
		// نص حر بالكامل (شوف CS_Countries)، فلو الأدمن كتب في شيت الترجمة
		// العربي "القاهرة" بدل "Cairo"، النص مبقاش متطابق حتى لو نفس المكان
		// فعليًا -- فكان السيشن العربي بيفضل من غير ترجمة مربوطة (بوست يتيم)،
		// وده اللي كان بيسبب: مفيش زرار سويتش لانجويدج خالص على سيشنز
		// العربي (مالهاش ترجمة معروفة)، وعلى سيشنز الإنجليزي زرار السويتش
		// كان بيظهر (بسبب إعداد "fallback to default language" على الـ CPT)
		// بس بيوديك لنفس المحتوى الإنجليزي وبس الاتجاه (RTL) بيتغيّر، مش
		// المحتوى الفعلي.
		$by_loc_index = array();
		$by_country   = array();
		if ( $source_master_id ) {
			$cache_key = 'cs_src_sessions_' . $source_master_id;
			$cached    = get_transient( $cache_key );

			if ( false === $cached || ! isset( $cached['by_loc_index'], $cached['by_country'] ) ) {
				$source_sessions = get_posts( array(
					'post_type'      => CS_CPT,
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'meta_key'       => CS_META_MASTER,
					'meta_value'     => $source_master_id,
				) );
				foreach ( $source_sessions as $source_session_id ) {
					$date      = get_post_meta( $source_session_id, CS_META_DATE, true );
					$country   = get_post_meta( $source_session_id, CS_META_COUNTRY, true );
					$loc_index = get_post_meta( $source_session_id, CS_META_LOC_INDEX, true );

					if ( '' !== $loc_index ) {
						$by_loc_index[ $date . '|' . (int) $loc_index ] = $source_session_id;
					}
					// النص القديم بردو، احتياطي (بيسيب آخر واحد لو فيه تكرار،
					// زي ما كان بيحصل قبل كده).
					$by_country[ $date . '|' . $country ] = $source_session_id;
				}
				$cached = array(
					'by_loc_index' => $by_loc_index,
					'by_country'   => $by_country,
				);
				// نص ساعة كفاية لأي كورس هياخد وقت أطول من كده مش طبيعي.
				set_transient( $cache_key, $cached, 30 * MINUTE_IN_SECONDS );
			} else {
				$by_loc_index = $cached['by_loc_index'];
				$by_country   = $cached['by_country'];
			}
		}

		foreach ( $sessions as $session_id ) {
			$source_session = 0;

			if ( $by_loc_index || $by_country ) {
				$date      = get_post_meta( $session_id, CS_META_DATE, true );
				$loc_index = get_post_meta( $session_id, CS_META_LOC_INDEX, true );

				if ( '' !== $loc_index ) {
					$key = $date . '|' . (int) $loc_index;
					if ( isset( $by_loc_index[ $key ] ) ) {
						$source_session = $by_loc_index[ $key ];
					}
				}

				if ( ! $source_session ) {
					// احتياطي: طابق بنص المكان القديم (شوف الشرح فوق).
					$country = get_post_meta( $session_id, CS_META_COUNTRY, true );
					$key     = $date . '|' . $country;
					if ( isset( $by_country[ $key ] ) ) {
						$source_session = $by_country[ $key ];
					}
				}
			}

			if ( $source_session ) {
				// اربطه كترجمة فعلية للسيشن الإنجليزي المقابل (نفس التاريخ والمكان).
				self::link_translation( $session_id, $source_session, $lang_code );
				continue;
			}

			// مفيش سيشن أصلي مقابل (أو مش ترجمة أصلاً) -- حط له اللغة بس.
			self::set_language( $session_id, $lang_code );
		}

		// لو الدفعة دي طلعت بالظبط SESSIONS_BATCH_SIZE، يبقى غالبًا فيه
		// دفعة تانية بعدها. لو أقل، يبقى دي آخر دفعة ومفيش داعي نجدول تاني
		// (هيتأكد ويرجع فاضي من نفسه المرة الجاية على أي حال، بس بلاش
		// نستنى دورة cron إضافية من غير داعي).
		if ( count( $sessions ) === self::SESSIONS_BATCH_SIZE ) {
			self::schedule_sessions_batch( $master_id, $lang_code, $source_master_id, $offset + self::SESSIONS_BATCH_SIZE );
		}
	}

	/**
	 * كود لغة بوست معيّن (زي "ar" أو "en"). بيرجع null لو WPML مش شغال
	 * أو لو مفيش لغة متحددة له لسه.
	 */
	public static function post_language( $post_id ) {
		if ( ! self::active() ) {
			return null;
		}

		$lang = apply_filters( 'wpml_element_language_code', null, array(
			'element_id'   => $post_id,
			'element_type' => 'post_' . CS_CPT,
		) );

		return $lang ? $lang : null;
	}
}

CS_WPML::init();
