<?php

/**
 * Feature: CSV Import
 * صفحة أدمن تحت مينيو Courses اسمها "Import CSV" بترفع شيت وتنشئ/تحدّث
 * كورسات (Master) بالظبط بنفس أسماء حقول ACF الموجودة في class-cs-acf.php.
 * بعد ما يتسجل كل كورس، بننادي CS_Recurrence::generate_sessions() يدوي
 * (نفس اللي بيحصل لما تحفظ الكورس من الشاشة العادية).
 *
 * أعمدة الشيت المتوقعة (بالترتيب ده أو بأي ترتيب، العبرة بالاسم في أول صف):
 *
 * title              - اسم الكورس (مطلوب)
 * category           - اسم الكاتيجوري (لو مش موجود هيتعمل تلقائي)
 * summary            - الوصف اللي بيظهر تحت العنوان في صفحة السنجل كورس
 * delivery_mode      - hybrid / online / in_person
 * language           - لغة أو أكتر مفصولين بـ / . مثال: English / Arabic / French
 *                        (مش لازم قايمة محددة -- اكتب أي لغة عايزها)
 * duration_hours     - رقم
 * base_start_date    - تاريخ أول سيشن بصيغة YYYY-MM-DD
 * recurrence         - weekly / biweekly (عدد أيام الكورس بيتحدد أوتوماتيك منها:
 *                        weekly = 5 أيام شغل، biweekly = 10 أيام شغل. مفيش عمود
 *                        منفصل لعدد الأيام، والسبت والأحد مالهومش وجود خالص)
 * countries_prices   - Cairo:1500:USD|Alex:800:USD|Mansoura:900:USD
 *                        (مكان:سعر:عملة مفصولين بـ |). المكان نص حر بالكامل --
 *                        ممكن يبقى اسم دولة ("Egypt") أو مدينة ("Cairo") أو أي
 *                        حاجة تانية، اكتبه زي ما انت عايز، مش لازم يكون من قايمة
 *                        دول محددة.
 * objectives         - Objective 1|Objective 2|Objective 3
 * schedule           - Day 1 Title: Point A;Point B||Day 2 Title: Point C;Point D
 * outline_pdf_url     - رابط ملف PDF لو موجود بالفعل في مكتبة الميديا (اختياري)
 * image_url           - رابط صورة الكورس (اختياري). لو موجود هيتنزّل ويتحط
 *                        كصورة مميزة (Featured Image) للكورس، وهيظهر في الكارت
 *                        وفي كل السيشنز المتولدة منه أوتوماتيك. لو العمود فاضي،
 *                        الكارت هيتعرض عادي من غير صورة.
 * course_id           - لو موجود، هيعدّل الكورس ده بدل ما يعمل واحد جديد (اختياري)
 */

if (! defined('ABSPATH')) {
	exit;
}

class CS_Import
{

	const NONCE_ACTION = 'cs_import_csv';

	public static function init()
	{
		add_action('admin_menu', array(__CLASS__, 'add_menu'));
		add_action('admin_post_cs_download_sample', array(__CLASS__, 'download_sample'));
	}

	public static function add_menu()
	{
		add_submenu_page(
			'edit.php?post_type=' . CS_CPT,
			'Import CSV',
			'Import CSV',
			'edit_posts',
			'cs-import-csv',
			array(__CLASS__, 'render_page')
		);
	}

	/* ================= صفحة الأدمن ================= */

	public static function render_page()
	{
		if (! current_user_can('edit_posts')) {
			return;
		}

		$results = null;

		if (! empty($_POST['cs_import_submit'])) {
			check_admin_referer(self::NONCE_ACTION);

			if (! empty($_FILES['cs_csv_file']['tmp_name'])) {
				$results = self::handle_upload($_FILES['cs_csv_file']['tmp_name']);
			} else {
				$results = array('error' => 'من فضلك اختار ملف CSV الأول.');
			}
		}

		$sample_url = wp_nonce_url(
			admin_url('admin-post.php?action=cs_download_sample'),
			'cs_download_sample'
		);
?>
		<div class="wrap">
			<h1>استيراد الكورسات من CSV</h1>

			<p>
				ارفع ملف CSV وهيتم إنشاء كورس (Master) لكل صف، وهيتولّد له السيشنز أوتوماتيك
				بنفس منطق التكرار المعتاد (زي لو حفظته يدوي من شاشة الكورس).
			</p>

			<p>
				<a href="<?php echo esc_url($sample_url); ?>" class="button">
					⬇ تحميل نموذج CSV فاضي (Sample Template)
				</a>
			</p>

			<?php if ($results) : ?>
				<?php self::render_results($results); ?>
			<?php endif; ?>

			<form method="post" enctype="multipart/form-data" style="margin-top:20px;">
				<?php wp_nonce_field(self::NONCE_ACTION); ?>
				<table class="form-table">
					<tr>
						<th><label for="cs_csv_file">ملف CSV</label></th>
						<td><input type="file" name="cs_csv_file" id="cs_csv_file" accept=".csv" required></td>
					</tr>
				</table>
				<?php submit_button('رفع واستيراد', 'primary', 'cs_import_submit'); ?>
			</form>

			<h2>شرح أعمدة الشيت</h2>
			<table class="widefat striped" style="max-width:900px;">
				<thead>
					<tr>
						<th>العمود</th>
						<th>الشرح</th>
						<th>مثال</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><code>title</code></td>
						<td>اسم الكورس (مطلوب)</td>
						<td>Strategic Leadership Program</td>
					</tr>
					<tr>
						<td><code>category</code></td>
						<td>اسم الكاتيجوري (بيتعمل تلقائي لو مش موجود)</td>
						<td>Leadership & Executive Coaching</td>
					</tr>
					<tr>
						<td><code>summary</code></td>
						<td>وصف الهيرو</td>
						<td>A modern capability-building program...</td>
					</tr>
					<tr>
						<td><code>delivery_mode</code></td>
						<td>hybrid / online / in_person</td>
						<td>hybrid</td>
					</tr>
					<tr>
						<td><code>language</code></td>
						<td>لغة أو أكتر مفصولين بـ <code>/</code> (مش قايمة محددة، اكتب أي لغة)</td>
						<td>English / Arabic / French</td>
					</tr>
					<tr>
						<td><code>duration_hours</code></td>
						<td>رقم</td>
						<td>40</td>
					</tr>
					<tr>
						<td><code>base_start_date</code></td>
						<td>YYYY-MM-DD</td>
						<td>2026-03-05</td>
					</tr>
					<tr>
						<td><code>recurrence</code></td>
						<td>weekly / biweekly — عدد الأيام بيتحدد أوتوماتيك منها (weekly=5, biweekly=10)، مفيش عمود منفصل لعدد الأيام</td>
						<td>weekly</td>
					</tr>
					<tr>
						<td><code>countries_prices</code></td>
						<td>المكان:السعر:العملة (المكان نص حر -- مدينة أو دولة أو أي حاجة)، كل مكان مفصول بـ <code>|</code></td>
						<td>Cairo:1500:USD|Alex:800:USD|Mansoura:900:USD</td>
					</tr>
					<tr>
						<td><code>objectives</code></td>
						<td>مفصولين بـ <code>|</code></td>
						<td>Frame the main decisions...|Use practical tools...</td>
					</tr>
					<tr>
						<td><code>schedule</code></td>
						<td>يوم:نقطة1;نقطة2، وكل يوم مفصول بـ <code>||</code></td>
						<td>Day 1 – Intro: Point A;Point B||Day 2 – Deep Dive: Point C</td>
					</tr>
					<tr>
						<td><code>outline_pdf_url</code></td>
						<td>لينك ملف PDF لو موجود في مكتبة الميديا (اختياري)</td>
						<td>https://site.com/wp-content/uploads/file.pdf</td>
					</tr>
					<tr>
						<td><code>image_url</code></td>
						<td>رابط صورة الكورس (اختياري). هتتنزّل وتتحط كصورة الكورس، وتتكرر تلقائي في كل السيشنز. سيبه فاضي لو مفيش صورة -- الكارت هيتعرض عادي من غيرها</td>
						<td>https://site.com/wp-content/uploads/course-cover.jpg</td>
					</tr>
					<tr>
						<td><code>course_id</code></td>
						<td>لو حطيته، هيعدّل الكورس ده بدل إنشاء واحد جديد (اختياري)</td>
						<td>142</td>
					</tr>
					<tr>
						<td><code>lang</code></td>
						<td>كود لغة الصف ده (محتاج WPML شغّال). سيبه فاضي للكورس الأصلي بلغة الموقع الافتراضية</td>
						<td>ar</td>
					</tr>
					<tr>
						<td><code>source_course_id</code></td>
						<td>لو الصف ده ترجمة لكورس أصلي: حط ID الكورس الإنجليزي هنا، وهيتستنسخله كل المواعيد والدول والأسعار تلقائي، وهيتربط كترجمة له في WPML، وهيتولّدله نفس عدد السيشنز</td>
						<td>142</td>
					</tr>
				</tbody>
			</table>

			<?php if (class_exists('CS_WPML') && ! CS_WPML::active()) : ?>
				<div class="notice notice-warning inline">
					<p>
						⚠️ عمودين <code>lang</code> و <code>source_course_id</code> مش هيشتغلوا لحد ما تثبّت وتفعّل بلجن <strong>WPML Multilingual CMS</strong>.
					</p>
				</div>
			<?php endif; ?>
		</div>
<?php
	}

	protected static function render_results($results)
	{
		if (! empty($results['error'])) {
			echo '<div class="notice notice-error"><p>' . esc_html($results['error']) . '</p></div>';
			return;
		}

		printf(
			'<div class="notice notice-success"><p>تم بنجاح: <strong>%d</strong> كورس جديد، <strong>%d</strong> كورس اتحدّث. عدد الأخطاء: <strong>%d</strong>.</p></div>',
			(int) $results['created'],
			(int) $results['updated'],
			count($results['errors'])
		);

		if (! empty($results['errors'])) {
			echo '<div class="notice notice-warning"><p><strong>أخطاء:</strong></p><ul style="list-style:disc;margin-right:20px;">';
			foreach ($results['errors'] as $err) {
				echo '<li>' . esc_html($err) . '</li>';
			}
			echo '</ul></div>';
		}

		if (! empty($results['rows'])) {
			echo '<table class="widefat striped" style="max-width:900px;"><thead><tr><th>الصف</th><th>العنوان</th><th>الحالة</th><th>Course ID</th></tr></thead><tbody>';
			foreach ($results['rows'] as $row) {
				echo '<tr>';
				echo '<td>' . (int) $row['line'] . '</td>';
				echo '<td>' . esc_html($row['title']) . '</td>';
				echo '<td>' . esc_html($row['status']) . '</td>';
				echo '<td>' . ($row['post_id'] ? '<a href="' . esc_url(get_edit_post_link($row['post_id'])) . '">#' . (int) $row['post_id'] . '</a>' : '-') . '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
	}

	/* ================= المعالجة ================= */

	protected static function handle_upload($tmp_path)
	{

		$handle = fopen($tmp_path, 'r');
		if (! $handle) {
			return array('error' => 'مقدرش أفتح الملف.');
		}

		// شيل الـ BOM لو موجود عشان أول عمود متتكسرش.
		$bom = fread($handle, 3);
		if ($bom !== "\xEF\xBB\xBF") {
			rewind($handle);
		}

		$headers = fgetcsv($handle);
		if (! $headers) {
			fclose($handle);
			return array('error' => 'الملف فاضي أو مش CSV صحيح.');
		}

		$headers = array_map(function ($h) {
			return strtolower(trim($h));
		}, $headers);

		$created = 0;
		$updated = 0;
		$errors  = array();
		$rows    = array();
		$line    = 1; // الصف 1 = الهيدر.

		while (($data = fgetcsv($handle)) !== false) {
			$line++;

			// صف فاضي بالكامل -> تخطّاه.
			if (count(array_filter($data, function ($v) {
				return trim((string) $v) !== '';
			})) === 0) {
				continue;
			}

			$row = array();
			foreach ($headers as $i => $key) {
				$row[$key] = isset($data[$i]) ? trim($data[$i]) : '';
			}

			$title = isset($row['title']) ? $row['title'] : '';
			if ('' === $title) {
				$errors[] = "صف {$line}: عمود title فاضي، اتخطّى.";
				continue;
			}

			$result = self::import_row($row, $line);

			if (is_wp_error($result)) {
				$errors[] = "صف {$line} ({$title}): " . $result->get_error_message();
				$rows[]   = array('line' => $line, 'title' => $title, 'status' => 'فشل', 'post_id' => 0);
				continue;
			}

			if ('created' === $result['status']) {
				$created++;
			} else {
				$updated++;
			}

			if (! empty($result['image_warning'])) {
				$errors[] = "صف {$line} ({$title}): الكورس اتحفظ، بس مشكلة في الصورة -- " . $result['image_warning'];
			}

			$rows[] = array(
				'line'    => $line,
				'title'   => $title,
				'status'  => 'created' === $result['status'] ? 'اتعمل' : 'اتحدّث',
				'post_id' => $result['post_id'],
			);
		}

		fclose($handle);

		return array(
			'created' => $created,
			'updated' => $updated,
			'errors'  => $errors,
			'rows'    => $rows,
		);
	}

	/**
	 * استيراد صف واحد -> إنشاء أو تحديث كورس ماستر + توليد السيشنز بتاعته.
	 *
	 * @return array|WP_Error { status: created|updated, post_id: int }
	 */
	protected static function import_row($row, $line)
	{

		$title = sanitize_text_field($row['title']);

		// تحديد الكورس: بـ course_id لو موجود، وإلا بحث بالعنوان (تحديث بدل تكرار).
		$post_id = 0;
		$status  = 'created';

		if (! empty($row['course_id'])) {
			$maybe_id = (int) $row['course_id'];
			if (get_post_type($maybe_id) === CS_CPT) {
				$post_id = $maybe_id;
				$status  = 'updated';
			}
		}

		if (! $post_id) {
			$existing = get_page_by_title($title, OBJECT, CS_CPT);
			if ($existing && CS_CPT::is_master($existing->ID)) {
				$post_id = $existing->ID;
				$status  = 'updated';
			}
		}

		$postarr = array(
			'post_title'  => $title,
			'post_type'   => CS_CPT,
			'post_status' => 'publish',
		);

		if ($post_id) {
			$postarr['ID'] = $post_id;
			$result_id     = wp_update_post($postarr, true);
		} else {
			$result_id = wp_insert_post($postarr, true);
		}

		if (is_wp_error($result_id)) {
			return $result_id;
		}

		$post_id = $result_id;

		// لو الصف ده ترجمة لكورس أصلي (عمود source_course_id)، استنسخ منه
		// كل حاجة (المواعيد، الدول، الأسعار...) الأول، وبعدين أعمدة الشيت
		// اللي جايه تحت هتستبدل بس النصوص المترجمة اللي فعلاً مكتوبة في الصف.
		$source_id = 0;
		if (! empty($row['source_course_id'])) {
			$maybe_source = (int) $row['source_course_id'];
			if ($maybe_source && get_post_type($maybe_source) === CS_CPT && $maybe_source !== $post_id) {
				$source_id = $maybe_source;
				if (class_exists('CS_WPML')) {
					CS_WPML::clone_master_fields($source_id, $post_id);
				}
			} else {
				return new WP_Error('bad_source', 'عمود source_course_id مش بيشاور على كورس موجود فعلاً. سيبه فاضي لو الكورس ده أصلي مش ترجمة لحاجة تانية.');
			}
		}

		// الكاتيجوري.
		if (! empty($row['category'])) {
			self::assign_category($post_id, $row['category']);
		}

		// حقول ACF البسيطة.
		if (isset($row['summary'])) {
			update_field('cs_summary', sanitize_textarea_field($row['summary']), $post_id);
		}
		if (! empty($row['delivery_mode'])) {
			update_field('cs_delivery_mode', sanitize_key($row['delivery_mode']), $post_id);
		}
		if (! empty($row['language'])) {
			update_field('cs_language', self::sanitize_languages($row['language']), $post_id);
		}
		if (! empty($row['duration_hours'])) {
			update_field('cs_duration_hours', (int) $row['duration_hours'], $post_id);
		}
		if (! empty($row['base_start_date'])) {
			$date = self::normalize_date($row['base_start_date']);
			if ($date) {
				update_field('cs_base_start_date', $date, $post_id);
			} else {
				return new WP_Error('bad_date', 'تاريخ base_start_date غلط. الصيغ المقبولة: 2026-03-05 أو 3/5/2026 أو 5/3/2026.');
			}
		}
		if (! empty($row['recurrence'])) {
			$rec = sanitize_key($row['recurrence']);
			if (in_array($rec, array('weekly', 'biweekly'), true)) {
				update_field('cs_recurrence', $rec, $post_id);
			}
		}

		// الأماكن والأسعار (repeater). المكان نص حر (مش لازم يبقى كود دولة).
		if (isset($row['countries_prices']) && '' !== $row['countries_prices']) {
			$country_rows = self::parse_country_prices($row['countries_prices']);
			if (empty($country_rows)) {
				return new WP_Error('bad_countries', 'عمود countries_prices متكتوبش صح، الصيغة: Cairo:1500:USD|Alex:800:USD');
			}
			update_field('cs_country_prices', $country_rows, $post_id);
		}

		// الأهداف (repeater).
		if (isset($row['objectives']) && '' !== $row['objectives']) {
			$objectives = array();
			foreach (explode('|', $row['objectives']) as $obj) {
				$obj = trim($obj);
				if ('' !== $obj) {
					$objectives[] = array('text' => sanitize_text_field($obj));
				}
			}
			if ($objectives) {
				update_field('cs_objectives', $objectives, $post_id);
			}
		}

		// الجدول اليومي (repeater جوه repeater).
		if (isset($row['schedule']) && '' !== $row['schedule']) {
			$schedule = self::parse_schedule($row['schedule']);
			if ($schedule) {
				update_field('cs_schedule', $schedule, $post_id);
			}
		}

		// ملف الـ PDF (اختياري، لازم يكون مرفوع في مكتبة الميديا بالفعل).
		if (! empty($row['outline_pdf_url'])) {
			$attachment_id = attachment_url_to_postid(esc_url_raw($row['outline_pdf_url']));
			if ($attachment_id) {
				update_field('cs_outline_pdf', $attachment_id, $post_id);
			}
		}

		// صورة الكورس (Featured Image). اختياري -- لو العمود فاضي، الكورس
		// (وكل السيشنز بتاعته) هيفضل من غير صورة عادي.
		$image_warning = '';
		if (! empty($row['image_url'])) {
			$image_result = self::attach_course_image(esc_url_raw($row['image_url']), $post_id, $title);
			if (is_wp_error($image_result)) {
				// خطأ في الصورة مش لازم يوقف باقي الصف -- سجّله وكمّل عادي.
				$image_warning = $image_result->get_error_message();
			}
		}

		// علّمه كماستر، وولّد السيشنز بتاعته (بنفس اللي بيحصل عند الحفظ اليدوي).
		update_post_meta($post_id, CS_META_IS_MASTER, 1);

		if (class_exists('CS_Recurrence')) {
			CS_Recurrence::generate_sessions($post_id);
		}

		// ربط اللغة والترجمة مع WPML (لو WPML شغّال ومحدد عمود lang في الصف).
		if (class_exists('CS_WPML') && CS_WPML::active()) {
			$lang_code = ! empty($row['lang']) ? sanitize_key($row['lang']) : '';

			if ($lang_code) {
				if ($source_id) {
					CS_WPML::link_translation($post_id, $source_id, $lang_code);
				} else {
					CS_WPML::set_language($post_id, $lang_code);
				}
				// خلي كل السيشنز اللي اتولدت للماستر ده بنفس لغته، وكل سيشن
				// (لو الصف ده ترجمة لكورس أصلي) هيتربط كترجمة فعلية للسيشن
				// الإنجليزي المقابل له (نفس التاريخ والدولة)، مش بس هيتحط له لغة.
				CS_WPML::tag_sessions_language($post_id, $lang_code, $source_id);
			}
		}

		return array('status' => $status, 'post_id' => $post_id, 'image_warning' => $image_warning);
	}

	/* ================= Helpers ================= */

	/**
	 * ينزّل صورة من رابط (image_url في الشيت) ويرفعها كـ Featured Image
	 * للكورس (الماستر). الصورة دي هي اللي هتظهر في الكارت، وبما إن كل
	 * السيشنز بتاعت الكورس بتقرا الصورة من الماستر (get_the_post_thumbnail_url
	 * بيتنادى بـ master_id دايمًا)، فبيتكرر تلقائي مع كل نسخه من غير أي كود إضافي.
	 *
	 * @param string $url     رابط الصورة.
	 * @param int    $post_id ID الكورس (الماستر).
	 * @param string $title   اسم الكورس (يتستخدم كـ alt/description للصورة).
	 * @return int|WP_Error   ID الـ attachment، أو WP_Error لو فشل التنزيل.
	 */
	protected static function attach_course_image($url, $post_id, $title)
	{
		if (! $url) {
			return new WP_Error('bad_image_url', 'رابط الصورة فاضي.');
		}

		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// media_sideload_image() بيحاول يحدد امتداد الصورة (jpg/png/..) من نفس
		// الرابط، ولو الرابط من نوع CDN زي Unsplash/imgix (رابط بيرجع صورة بس من
		// غير .jpg/.png ظاهر في المسار، وبدله بارامترز زي ?w=1200) بيفشل ويرجّع
		// "Invalid image URL" حتى لو الرابط شغال فعلاً وبيرجّع صورة حقيقية. عشان
		// كده بننزّل الملف بنفسنا الأول، وبعدين نحدد نوعه من محتواه الفعلي (مش من
		// شكل الرابط) باستخدام wp_check_filetype_and_ext().
		$tmp_file = download_url($url);
		if (is_wp_error($tmp_file)) {
			return $tmp_file;
		}

		$filetype = wp_check_filetype_and_ext($tmp_file, $url);
		$ext      = ! empty($filetype['ext']) ? $filetype['ext'] : '';

		if (! $ext) {
			// احتياطي أخير: جرب نقرا نوع الصورة من الـ bytes نفسها مباشرة.
			$size = @getimagesize($tmp_file);
			$map  = array(
				IMAGETYPE_JPEG => 'jpg',
				IMAGETYPE_PNG  => 'png',
				IMAGETYPE_GIF  => 'gif',
				IMAGETYPE_WEBP => 'webp',
			);
			if ($size && isset($map[$size[2]])) {
				$ext = $map[$size[2]];
			}
		}

		if (! $ext) {
			@unlink($tmp_file);
			/* translators: %s: image URL from the import sheet. */
			return new WP_Error('bad_image_url', sprintf('الرابط ده مش صورة صالحة أو مش متاح: %s', $url));
		}

		$file_array = array(
			'name'     => sanitize_file_name($title) . '-' . wp_generate_password(6, false) . '.' . $ext,
			'tmp_name' => $tmp_file,
		);

		$attachment_id = media_handle_sideload($file_array, $post_id, $title);

		if (is_wp_error($attachment_id)) {
			@unlink($tmp_file);
			return $attachment_id;
		}

		set_post_thumbnail($post_id, $attachment_id);

		return $attachment_id;
	}

	protected static function assign_category($post_id, $category_name)
	{
		$category_name = sanitize_text_field($category_name);
		$term = get_term_by('name', $category_name, CS_TAX);

		if (! $term) {
			$inserted = wp_insert_term($category_name, CS_TAX);
			if (is_wp_error($inserted)) {
				return;
			}
			$term_id = $inserted['term_id'];
		} else {
			$term_id = $term->term_id;
		}

		wp_set_object_terms($post_id, (int) $term_id, CS_TAX, false);
	}

	/**
	 * "Cairo:1500:USD|Alex:800:USD|Mansoura:900:USD" ->
	 * [ ['country'=>'Cairo','price'=>1500,'currency'=>'USD'], ... ]
	 *
	 * المكان (أول جزء قبل أول ":") نص حر بالكامل -- ممكن يبقى اسم دولة أو
	 * مدينة أو أي حاجة تانية، بيتاخد زي ما اتكتب بالظبط (بعد تنضيف بسيط)
	 * من غير أي تحقق من قايمة دول محددة.
	 */
	protected static function parse_country_prices($raw)
	{
		$rows = array();
		foreach (explode('|', $raw) as $chunk) {
			$chunk = trim($chunk);
			if ('' === $chunk) {
				continue;
			}
			$parts    = array_map('trim', explode(':', $chunk));
			$location = isset($parts[0]) ? sanitize_text_field($parts[0]) : '';

			if ('' === $location) {
				continue;
			}

			$rows[] = array(
				'country'  => $location,
				'price'    => isset($parts[1]) ? (float) $parts[1] : 0,
				'currency' => isset($parts[2]) && $parts[2] !== '' ? strtoupper($parts[2]) : 'USD',
			);
		}
		return $rows;
	}

	/**
	 * "English / Arabic / French" -> "English / Arabic / French" (بعد تنضيف
	 * المسافات الزيادة حوالين كل لغة). بيسيب النص زي ما اتكتب بالظبط --
	 * مفيش قايمة لغات محددة، اكتب أي لغة عايزها مفصولة بـ "/".
	 */
	protected static function sanitize_languages($raw)
	{
		$parts = array_map('trim', explode('/', $raw));
		$parts = array_filter($parts, function ($p) {
			return '' !== $p;
		});
		$parts = array_map('sanitize_text_field', $parts);
		return implode(' / ', $parts);
	}

	/**
	 * "Day 1 – Intro: Point A;Point B||Day 2: Point C" -> repeater array
	 */
	protected static function parse_schedule($raw)
	{
		$days = array();
		foreach (explode('||', $raw) as $day_chunk) {
			$day_chunk = trim($day_chunk);
			if ('' === $day_chunk) {
				continue;
			}

			$colon_pos = strpos($day_chunk, ':');
			if (false === $colon_pos) {
				$day_title = $day_chunk;
				$points_raw = '';
			} else {
				$day_title  = trim(substr($day_chunk, 0, $colon_pos));
				$points_raw = trim(substr($day_chunk, $colon_pos + 1));
			}

			$points = array();
			if ('' !== $points_raw) {
				foreach (explode(';', $points_raw) as $point) {
					$point = trim($point);
					if ('' !== $point) {
						$points[] = array('text' => sanitize_text_field($point));
					}
				}
			}

			$days[] = array(
				'day_title' => sanitize_text_field($day_title),
				'points'    => $points,
			);
		}
		return $days;
	}

	/**
	 * إكسيل بيحفظ التواريخ بصيغ مختلفة حسب لغة الجهاز (زي 3/5/2026 أو
	 * 05/03/2026)، مش بس YYYY-MM-DD. الدالة دي بتجرب كذا صيغة معروفة
	 * قبل ما ترفض التاريخ خالص.
	 */
	protected static function normalize_date($raw)
	{
		$raw = trim($raw);
		if ('' === $raw) {
			return false;
		}

		// الصيغ المقبولة بالترتيب. بنبدأ بـ يوم/شهر/سنة (زي مصر وأوروبا) لأن
		// دي الصيغة اللي بتتكتب بيها التواريخ في الشيت عادةً. اللي زي "3/5/2026"
		// هيتقرا 3 مايو (مش مارس 5). لو اليوم أكبر من 12 (يعني مينفعش يبقى شهر)،
		// بيرجع تلقائي لصيغة أمريكا شهر/يوم عشان يقدر يقرا تواريخ إكسيل الأمريكي.
		$formats = array('Y-m-d', 'j/n/Y', 'd/m/Y', 'n/j/Y', 'm/d/Y', 'Y/m/d');

		foreach ($formats as $format) {
			$date = DateTime::createFromFormat('!' . $format, $raw);
			if ($date instanceof DateTime) {
				$errors = DateTime::getLastErrors();
				if (empty($errors['warning_count']) && empty($errors['error_count'])) {
					return $date->format('Y-m-d');
				}
			}
		}

		return false;
	}

	/* ================= نموذج CSV فاضي ================= */

	public static function download_sample()
	{
		check_admin_referer('cs_download_sample');

		if (! current_user_can('edit_posts')) {
			wp_die('غير مسموح.');
		}

		$headers = array(
			'title',
			'category',
			'summary',
			'delivery_mode',
			'language',
			'duration_hours',
			'base_start_date',
			'recurrence',
			'countries_prices',
			'objectives',
			'schedule',
			'outline_pdf_url',
			'image_url',
			'course_id',
			'lang',
			'source_course_id',
		);

		$sample_row_en = array(
			'Customer Data, Analytics & Personalization Strategies',
			'Digital Transformation & Future Skills',
			'A modern capability-building program centered on customer data and personalization.',
			'hybrid',
			'English / Arabic',
			'40',
			'2026-03-05',
			'weekly',
			'Cairo:1500:USD|Alex:800:USD|Riyadh:900:USD',
			'Frame the main decisions involved in customer data strategy.|Use practical tools to improve personalization.',
			'Day 1 - Data Landscape: Frame core concepts;Assess current practices||Day 2 - Segmentation: Define strong segmentation;Diagnose bottlenecks',
			'',
			'https://images.unsplash.com/photo-1552664730-d307ca884978?w=800',
			'',
			'en',
			'',
		);

		// مثال صف الترجمة العربية لنفس الكورس -- لاحظ إن كل أعمدة المواعيد
		// والدول سايبينها فاضية، لأنها هتتاخد أوتوماتيك من source_course_id.
		$sample_row_ar = array(
			'استراتيجيات بيانات العملاء والتحليلات والتخصيص',
			'التحول الرقمي ومهارات المستقبل',
			'برنامج بناء قدرات حديث يركز على بيانات العملاء والتخصيص.',
			'',
			'',
			'',
			'',
			'',
			'صياغة القرارات الأساسية المتعلقة باستراتيجية بيانات العملاء.|استخدام أدوات عملية لتحسين التخصيص.',
			'اليوم 1 - خريطة البيانات: صياغة المفاهيم الأساسية;تقييم الممارسات الحالية||اليوم 2 - التقسيم: تحديد تقسيم قوي;تشخيص نقاط الاختناق',
			'',
			'',
			'',
			'ar',
			'123', // غيّرها لـ ID الكورس الإنجليزي الحقيقي بعد ما يترفع.
		);

		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename=courses-sample-template.csv');

		$out = fopen('php://output', 'w');
		fputs($out, "\xEF\xBB\xBF"); // BOM عشان اكسل يقرا العربي والإنجليزي صح.
		fputcsv($out, $headers);
		fputcsv($out, $sample_row_en);
		fputcsv($out, $sample_row_ar);
		fclose($out);
		exit;
	}
}

CS_Import::init();
