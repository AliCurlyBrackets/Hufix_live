<?php
/**
 * Feature: WPML Linking
 * مسؤول عن حاجة واحدة بس: تحديد لغة بوست معيّن، وربطه كترجمة لبوست تاني
 * (بنفس trid) باستخدام الـ API الرسمي بتاع WPML. مبيعملش أي ترجمة نصوص
 * فعلية -- ده شغل الأدمن (بيكتب النص العربي في الشيت)، إحنا بس بنربط.
 *
 * محتاج WPML Multilingual CMS شغّال وميظبطش عليه.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CS_WPML {

	/** هل WPML شغّال فعلاً على الموقع؟ */
	public static function active() {
		return defined( 'ICL_SITEPRESS_VERSION' ) || class_exists( 'SitePress' );
	}

	/** كود اللغة الافتراضي للموقع (مثلاً "en"). */
	public static function default_language() {
		$lang = apply_filters( 'wpml_default_language', null );
		return $lang ? $lang : 'en';
	}

	/**
	 * حدّد لغة بوست. لو مش متحدد له trid قبل كده، هيتعمله واحد جديد تلقائي.
	 *
	 * @param int    $post_id
	 * @param string $lang_code كود اللغة زي "en" أو "ar"
	 */
	public static function set_language( $post_id, $lang_code ) {
		if ( ! self::active() ) {
			return;
		}

		$element_type = 'post_' . CS_CPT;
		$trid         = apply_filters( 'wpml_element_trid', null, $post_id, $element_type );

		do_action( 'wpml_set_element_language_details', array(
			'element_id'           => $post_id,
			'element_type'         => $element_type,
			'trid'                 => $trid, // null = هيتعمله trid جديد.
			'language_code'        => $lang_code,
			'source_language_code' => null,
		) );
	}

	/**
	 * اربط $post_id كترجمة لـ $source_id بلغة $lang_code.
	 * لو $source_id لسه مالوش لغة متحددة، هيتحط في اللغة الافتراضية للموقع الأول.
	 *
	 * @return bool نجح الربط ولا لأ
	 */
	public static function link_translation( $post_id, $source_id, $lang_code ) {
		if ( ! self::active() ) {
			return false;
		}
		if ( ! $post_id || ! $source_id || $post_id === $source_id ) {
			return false;
		}
		if ( get_post_type( $source_id ) !== CS_CPT ) {
			return false;
		}

		$element_type = 'post_' . CS_CPT;

		// تأكد إن الأصل نفسه متحدد له لغة (مهم عشان الـ trid يتظبط صح).
		$source_lang = apply_filters( 'wpml_element_language_code', null, array(
			'element_id'   => $source_id,
			'element_type' => $element_type,
		) );

		if ( ! $source_lang ) {
			$source_lang = self::default_language();
			self::set_language( $source_id, $source_lang );
		}

		$trid = apply_filters( 'wpml_element_trid', null, $source_id, $element_type );

		do_action( 'wpml_set_element_language_details', array(
			'element_id'           => $post_id,
			'element_type'         => $element_type,
			'trid'                 => $trid,
			'language_code'        => $lang_code,
			'source_language_code' => $source_lang,
		) );

		return true;
	}

	/**
	 * استنسخ كل حقول ACF البسيطة (المواعيد، الدول، الأسعار، المدة...) من
	 * كورس أصلي لكورس تاني. بنستخدمها قبل ما نطبّق أعمدة الشيت المترجمة،
	 * عشان الكورس العربي "يدابلكيت" هيكل الأصلي بالظبط (نفس التواريخ والدول)
	 * وبعدين بس نستبدل النصوص بالترجمة اللي في الصف.
	 */
	public static function clone_master_fields( $source_id, $target_id ) {
		$fields = array(
			'cs_summary',
			'cs_delivery_mode',
			'cs_language',
			'cs_duration_hours',
			'cs_country_prices',
			'cs_base_start_date',
			'cs_recurrence',
			'cs_objectives',
			'cs_schedule',
			'cs_outline_pdf',
		);

		foreach ( $fields as $field ) {
			$value = get_field( $field, $source_id );
			if ( null !== $value && '' !== $value ) {
				update_field( $field, $value, $target_id );
			}
		}

		// نفس الكاتيجوري (لو الصف مادّاش category مختلفة، هيتستبدل بعدين لو موجودة).
		$terms = wp_get_object_terms( $source_id, CS_TAX, array( 'fields' => 'ids' ) );
		if ( $terms && ! is_wp_error( $terms ) ) {
			wp_set_object_terms( $target_id, $terms, CS_TAX );
		}
	}

	/**
	 * حط نفس لغة الماستر على كل السيشنز بتاعته (عشان WPML يفلتر صح
	 * في الفرونت حسب لغة الموقع الحالية). لو الماستر ده أصلاً ترجمة لماستر
	 * تاني ($source_master_id)، كل سيشن عربي (مثلاً) بيتربط كـ "ترجمة" فعلية
	 * للسيشن الإنجليزي المقابل له (نفس التاريخ + نفس الدولة)، مش بس بيتحط
	 * له لغة لوحده من غير ربط. من غير الربط ده، WPML بيعتبر السيشنز
	 * المترجمة بوستات "يتيمة" (مالهاش أصل)، وغالبًا بيستبعدها من العرض/الفلاتر
	 * زي ما ظهر لما اتعمل import لشيت عربي (اتترجم الماستر بس، من غير سيشناته).
	 *
	 * @param int    $master_id        ID الماستر (المترجَم، مثلاً العربي).
	 * @param string $lang_code        كود لغة الماستر ده.
	 * @param int    $source_master_id (اختياري) ID الماستر الأصلي لو ده ترجمة له.
	 */
	public static function tag_sessions_language( $master_id, $lang_code, $source_master_id = 0 ) {
		if ( ! self::active() ) {
			return;
		}

		$sessions = get_posts( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_key'       => CS_META_MASTER,
			'meta_value'     => $master_id,
		) );

		// لو ده ترجمة لماستر أصلي، جيب سيشنزه واعمل فهرس (date|country) -> session_id
		// عشان نلاقي بسرعة السيشن الإنجليزي المقابل لكل سيشن عربي.
		$source_sessions_by_key = array();
		if ( $source_master_id ) {
			$source_sessions = get_posts( array(
				'post_type'      => CS_CPT,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => CS_META_MASTER,
				'meta_value'     => $source_master_id,
			) );
			foreach ( $source_sessions as $source_session_id ) {
				$date    = get_post_meta( $source_session_id, CS_META_DATE, true );
				$country = get_post_meta( $source_session_id, CS_META_COUNTRY, true );
				$source_sessions_by_key[ $date . '|' . $country ] = $source_session_id;
			}
		}

		foreach ( $sessions as $session_id ) {
			if ( $source_sessions_by_key ) {
				$date          = get_post_meta( $session_id, CS_META_DATE, true );
				$country       = get_post_meta( $session_id, CS_META_COUNTRY, true );
				$key           = $date . '|' . $country;
				$source_session = isset( $source_sessions_by_key[ $key ] ) ? $source_sessions_by_key[ $key ] : 0;

				if ( $source_session ) {
					// اربطه كترجمة فعلية للسيشن الإنجليزي المقابل (نفس التاريخ والدولة).
					self::link_translation( $session_id, $source_session, $lang_code );
					continue;
				}
			}

			// مفيش سيشن أصلي مقابل (أو مش ترجمة أصلاً) -- حط له اللغة بس.
			self::set_language( $session_id, $lang_code );
		}
	}

	/**
	 * كود لغة بوست معيّن (زي "ar" أو "en"). بيرجع null لو WPML مش شغال
	 * أو لو مفيش لغة متحددة له لسه.
	 */
	public static function post_language( $post_id ) {
		if ( ! self::active() ) {
			return null;
		}

		$lang = apply_filters( 'wpml_element_language_code', null, array(
			'element_id'   => $post_id,
			'element_type' => 'post_' . CS_CPT,
		) );

		return $lang ? $lang : null;
	}
}
