<?php
/**
 * Feature: Countries
 * مصدر واحد لدول العالم. أي فيتشر محتاجة الدول بتناديه من هنا بس.
 * الكود = ISO2، والاسم = اللي بيتعرض. سهل تضيف اسم عربي بعدين.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CS_Countries {

	/**
	 * كل الدول: code => name.
	 * @return array
	 */
	public static function all() {
		$list = array(
			'EG' => 'Egypt', 'SA' => 'Saudi Arabia', 'AE' => 'United Arab Emirates',
			'QA' => 'Qatar', 'KW' => 'Kuwait', 'BH' => 'Bahrain', 'OM' => 'Oman',
			'JO' => 'Jordan', 'LB' => 'Lebanon', 'IQ' => 'Iraq', 'SY' => 'Syria',
			'YE' => 'Yemen', 'PS' => 'Palestine', 'SD' => 'Sudan', 'LY' => 'Libya',
			'TN' => 'Tunisia', 'DZ' => 'Algeria', 'MA' => 'Morocco', 'MR' => 'Mauritania',
			'US' => 'United States', 'CA' => 'Canada', 'MX' => 'Mexico',
			'GB' => 'United Kingdom', 'IE' => 'Ireland', 'FR' => 'France',
			'DE' => 'Germany', 'IT' => 'Italy', 'ES' => 'Spain', 'PT' => 'Portugal',
			'NL' => 'Netherlands', 'BE' => 'Belgium', 'LU' => 'Luxembourg',
			'CH' => 'Switzerland', 'AT' => 'Austria', 'SE' => 'Sweden',
			'NO' => 'Norway', 'DK' => 'Denmark', 'FI' => 'Finland', 'IS' => 'Iceland',
			'PL' => 'Poland', 'CZ' => 'Czechia', 'SK' => 'Slovakia', 'HU' => 'Hungary',
			'RO' => 'Romania', 'BG' => 'Bulgaria', 'GR' => 'Greece', 'HR' => 'Croatia',
			'RS' => 'Serbia', 'UA' => 'Ukraine', 'RU' => 'Russia', 'TR' => 'Turkey',
			'CY' => 'Cyprus', 'MT' => 'Malta',
			'CN' => 'China', 'JP' => 'Japan', 'KR' => 'South Korea', 'IN' => 'India',
			'PK' => 'Pakistan', 'BD' => 'Bangladesh', 'ID' => 'Indonesia',
			'MY' => 'Malaysia', 'SG' => 'Singapore', 'TH' => 'Thailand',
			'VN' => 'Vietnam', 'PH' => 'Philippines', 'HK' => 'Hong Kong',
			'AU' => 'Australia', 'NZ' => 'New Zealand',
			'ZA' => 'South Africa', 'NG' => 'Nigeria', 'KE' => 'Kenya',
			'ET' => 'Ethiopia', 'GH' => 'Ghana', 'TZ' => 'Tanzania',
			'BR' => 'Brazil', 'AR' => 'Argentina', 'CL' => 'Chile',
			'CO' => 'Colombia', 'PE' => 'Peru',
		);

		/**
		 * فلتر عشان تقدر تضيف/تعدل الدول من غير ما تلمس الفايل ده.
		 */
		return apply_filters( 'cs_countries_list', $list );
	}

	/**
	 * اسم الدولة من الكود.
	 */
	public static function name( $code ) {
		$all = self::all();
		return isset( $all[ $code ] ) ? $all[ $code ] : $code;
	}

	/**
	 * تشيك إن الكود سليم.
	 */
	public static function exists( $code ) {
		return array_key_exists( strtoupper( $code ), self::all() );
	}

	/**
	 * تحويل قائمة أكواد (من الشيت مثلا "EG,SA,AE") لأكواد نضيفة صالحة.
	 */
	public static function sanitize_codes( $raw ) {
		if ( is_string( $raw ) ) {
			$raw = array_map( 'trim', explode( ',', $raw ) );
		}
		$out = array();
		foreach ( (array) $raw as $code ) {
			$code = strtoupper( trim( $code ) );
			if ( $code && self::exists( $code ) ) {
				$out[] = $code;
			}
		}
		return array_values( array_unique( $out ) );
	}
}