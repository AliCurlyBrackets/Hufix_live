<?php
/**
 * Feature: Recurrence Engine
 * القلب بتاع السيستم. مسؤول عن:
 *   1) توليد الـ Sessions من الماستر: من تاريخ البداية -> آخر السنة،
 *      كل أسبوع/أسبوعين، مضروبة في عدد الدول المختارة.
 *   2) المزامنة: السيشن ما بيخزّنش محتوى، بيقرأ من الماستر ->
 *      فأي تعديل في الماستر بيظهر في كل السيشنز على طول (زي ما طلبت).
 *   3) التجديد السنوي: كرون يومي يولّد سيشنز السنة الجديدة وينضّف القديمة.
 *
 * مبدأ التصميم: السيشن = { master_id, date, country } بس. مفيش تكرار للمحتوى.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CS_Recurrence {

	public static function init() {
		// كل ما الماستر يتحفظ -> نعيد بناء السيشنز بتاعته.
		add_action( 'acf/save_post', array( __CLASS__, 'on_master_save' ), 20 );

		// الكرون اليومي: تجديد سنوي + تنظيف.
		add_action( 'cs_daily_maintenance', array( __CLASS__, 'daily_maintenance' ) );
	}

	/**
	 * لما الماستر يتحفظ من لوحة التحكم.
	 */
	public static function on_master_save( $post_id ) {
		if ( get_post_type( $post_id ) !== CS_CPT ) {
			return;
		}
		// السيشنز ملهاش داعي تعيد توليد سيشنز.
		if ( CS_CPT::is_master( $post_id ) === false && get_post_meta( $post_id, CS_META_MASTER, true ) ) {
			return;
		}

		// أول ما نحفظ كورس من الأدمن، نعتبره ماستر.
		update_post_meta( $post_id, CS_META_IS_MASTER, 1 );

		self::generate_sessions( $post_id );
	}

	/**
	 * توليد/تحديث سيشنز ماستر معيّن للسنة الحالية.
	 * idempotent: لو السيشن موجود بنفس (تاريخ+دولة) مبيتعملش تاني.
	 *
	 * @param int      $master_id
	 * @param int|null $year      السنة (افتراضي: السنة الحالية).
	 */
	public static function generate_sessions( $master_id, $year = null ) {
		$year = $year ? (int) $year : (int) current_time( 'Y' );

		$countries = (array) get_field( 'cs_countries', $master_id );
		$countries = CS_Countries::sanitize_codes( $countries );
		if ( empty( $countries ) ) {
			return; // مفيش دول -> مفيش سيشنز
		}

		$interval   = get_field( 'cs_recurrence', $master_id ) ?: 'weekly';
		$step_days  = ( 'biweekly' === $interval ) ? 14 : 7;
		$duration   = (int) get_field( 'cs_duration_days', $master_id ) ?: 5;

		// تاريخ البداية: المُدخل أو النهاردة، بس مش أقدم من بداية السنة المطلوبة.
		$base = get_field( 'cs_base_start_date', $master_id );
		$start = $base ? strtotime( $base ) : current_time( 'timestamp' );

		$year_start = strtotime( "$year-01-01" );
		$year_end   = strtotime( "$year-12-31" );
		if ( $start < $year_start ) {
			$start = $year_start;
		}

		// نجيب السيشنز الموجودة عشان نعرف نبني اللي ناقص بس.
		$existing = self::existing_session_keys( $master_id, $year );

		for ( $ts = $start; $ts <= $year_end; $ts = strtotime( "+{$step_days} days", $ts ) ) {
			$date = gmdate( 'Y-m-d', $ts );

			foreach ( $countries as $country ) {
				$key = $date . '|' . $country;
				if ( isset( $existing[ $key ] ) ) {
					continue; // موجود بالفعل
				}
				self::create_session( $master_id, $date, $country, $duration );
			}
		}
	}

	/**
	 * إنشاء سيشن واحد (بوست خفيف بيشاور على الماستر).
	 */
	protected static function create_session( $master_id, $date, $country, $duration_days ) {
		$master = get_post( $master_id );
		if ( ! $master ) {
			return 0;
		}

		$session_id = wp_insert_post( array(
			'post_type'   => CS_CPT,
			'post_status' => 'publish',
			'post_title'  => $master->post_title, // للعرض في الأدمن بس
			'post_parent' => $master_id,
		) );

		if ( is_wp_error( $session_id ) || ! $session_id ) {
			return 0;
		}

		update_post_meta( $session_id, CS_META_MASTER, $master_id );
		update_post_meta( $session_id, CS_META_DATE, $date );
		update_post_meta( $session_id, CS_META_COUNTRY, $country );

		// تاريخ النهاية = البداية + (المدة - 1).
		$end = gmdate( 'Y-m-d', strtotime( "+" . max( 0, $duration_days - 1 ) . " days", strtotime( $date ) ) );
		update_post_meta( $session_id, '_cs_session_end', $end );

		// السيشن ياخد نفس كاتيجوري الماستر.
		$terms = wp_get_object_terms( $master_id, CS_TAX, array( 'fields' => 'ids' ) );
		if ( $terms && ! is_wp_error( $terms ) ) {
			wp_set_object_terms( $session_id, $terms, CS_TAX );
		}

		return $session_id;
	}

	/**
	 * مفاتيح السيشنز الموجودة (date|country) لماستر في سنة.
	 */
	protected static function existing_session_keys( $master_id, $year ) {
		$q = new WP_Query( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_MASTER, 'value' => $master_id ),
				array(
					'key'     => CS_META_DATE,
					'value'   => array( "$year-01-01", "$year-12-31" ),
					'compare' => 'BETWEEN',
					'type'    => 'DATE',
				),
			),
		) );

		$keys = array();
		foreach ( $q->posts as $sid ) {
			$date    = get_post_meta( $sid, CS_META_DATE, true );
			$country = get_post_meta( $sid, CS_META_COUNTRY, true );
			$keys[ $date . '|' . $country ] = $sid;
		}
		return $keys;
	}

	/* ===================== Sync ===================== */
	// ملاحظة: مفيش داعي لكود مزامنة معقّد. لإن السيشن بيقرأ المحتوى من الماستر
	// وقت العرض (شوف cs_field() تحت)، فأي تعديل في الماستر بيبان في كل السيشنز
	// فورًا. الحاجة الوحيدة اللي بتتغير لما تعدّل الدول/التكرار هي عدد السيشنز،
	// وده on_master_save بيتكفّل بيه.

	/**
	 * Helper عام: هات قيمة حقل بغض النظر إنت واقف على سيشن ولا ماستر.
	 * أي template بتستخدمه عشان "التعديل يبان في الكوبي".
	 */
	public static function field( $name, $post_id = null ) {
		$post_id   = $post_id ?: get_the_ID();
		$master_id = CS_CPT::master_id( $post_id );
		return get_field( $name, $master_id );
	}

	/* ================= Yearly Renewal ================= */

	/**
	 * كرون يومي:
	 *  - يحذف السيشنز اللي عدّى تاريخها (تنظيف).
	 *  - في بداية كل سنة (أو لو ناقص) يولّد سيشنز السنة الحالية لكل الماسترز.
	 */
	public static function daily_maintenance() {
		$today = current_time( 'Y-m-d' );
		$year  = (int) current_time( 'Y' );

		// 1) تنظيف السيشنز القديمة.
		$old = new WP_Query( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_MASTER, 'compare' => 'EXISTS' ),
				array( 'key' => '_cs_session_end', 'value' => $today, 'compare' => '<', 'type' => 'DATE' ),
			),
		) );
		foreach ( $old->posts as $sid ) {
			wp_delete_post( $sid, true );
		}

		// 2) ضمان سيشنز السنة الحالية لكل الماسترز.
		$masters = new WP_Query( array(
			'post_type'      => CS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => CS_META_IS_MASTER, 'value' => 1 ),
			),
		) );
		foreach ( $masters->posts as $master_id ) {
			self::generate_sessions( $master_id, $year );
		}
	}
}

CS_Recurrence::init();

/**
 * Wrapper قصير تستخدمه في الـ templates بدل get_field.
 * بيضمن إن السيشن بيقرأ محتوى الماستر.
 */
function cs_field( $name, $post_id = null ) {
	return CS_Recurrence::field( $name, $post_id );
}