<?php
/**
 * Feature: Course Post Type
 * بوست تايب واحد اسمه course بيخدم حاجتين:
 *   - Master  (قالب مخفي، فيه كل المحتوى) -> _cs_is_master = 1
 *   - Session (النسخة المتكررة، بتاريخ + دولة، بتقرأ محتواها من الماستر)
 *
 * الـ Sessions هي اللي بتتعرض قدام. الماستر مخفي عن الفرونت.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CS_CPT {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		// اخفاء الماستر من كل كويريز الفرونت.
		add_action( 'pre_get_posts', array( __CLASS__, 'hide_masters_from_front' ) );
	}

	public static function register() {
		$labels = array(
			'name'          => 'Courses',
			'singular_name' => 'Course',
			'add_new_item'  => 'Add New Course',
			'edit_item'     => 'Edit Course',
			'search_items'  => 'Search Courses',
			'menu_name'     => 'Courses',
		);

		register_post_type( CS_CPT, array(
			'labels'       => $labels,
			'public'       => true,
			'has_archive'  => true,
			'show_in_rest' => true, // مهم لو هتستعمله في الموبايل API بعدين
			'menu_icon'    => 'dashicons-welcome-learn-more',
			'rewrite'      => array( 'slug' => 'courses' ),
			'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
			'taxonomies'   => array( CS_TAX ),
		) );
	}

	/**
	 * الماستر ما يظهرش في أي كويري قدام (بس السيشنز).
	 */
	public static function hide_masters_from_front( $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return;
		}
		if ( ! self::is_course_query( $query ) ) {
			return;
		}

		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = array(
			'key'     => CS_META_IS_MASTER,
			'compare' => 'NOT EXISTS',
		);
		$query->set( 'meta_query', $meta_query );
	}

	/**
	 * تشيك إن الكويري بتخص الكورسات (archive / taxonomy).
	 */
	protected static function is_course_query( $query ) {
		return $query->is_post_type_archive( CS_CPT ) || $query->is_tax( CS_TAX );
	}

	/* ============ Helpers مشتركة لباقي الفيتشرز ============ */

	/** هل البوست ده ماستر؟ */
	public static function is_master( $post_id ) {
		return (bool) get_post_meta( $post_id, CS_META_IS_MASTER, true );
	}

	/** يرجّع ID الماستر بتاع سيشن (أو نفس الـ ID لو هو ماستر). */
	public static function master_id( $post_id ) {
		$master = (int) get_post_meta( $post_id, CS_META_MASTER, true );
		return $master ? $master : (int) $post_id;
	}
}

CS_CPT::init();