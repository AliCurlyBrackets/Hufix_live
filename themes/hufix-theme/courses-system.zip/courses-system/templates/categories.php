<?php
/**
 * Template: Course Categories (الصفحة 1)
 * إسلايدر + شبكة الكاتيجوري. كل كاتيجوري باسمها وصورتها، والضغط عليها
 * بيوديك لأرشيف الكاتيجوري (الصفحة 2).
 *
 * الماركب مطابق لـ tg-section بتاعك، بس البيانات من التاكسونومي.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// إسلايدر عام (من غير كاتيجوري محددة).
include CS_PATH . 'templates/partial-slider.php';

// كل الكاتيجوريز اللي ليها كورسات.
$terms = get_terms( array(
	'taxonomy'   => CS_TAX,
	'hide_empty' => false,
	'orderby'    => 'name',
) );
?>

<section class="tg-section">
	<div class="tg-container">

		<h2 class="tg-heading"><?php esc_html_e( 'Training category', 'courses-system' ); ?></h2>
		<p class="tg-subheading"><?php esc_html_e( 'Our top-requested training themes include:', 'courses-system' ); ?></p>

		<div class="tg-grid">
			<?php if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) : ?>
				<?php foreach ( $terms as $term ) :
					$img  = CS_Taxonomy::image_url( $term->term_id, 'medium' );
					$link = get_term_link( $term );
				?>
					<div class="tg-item">
						<a class="tg-card" href="<?php echo esc_url( $link ); ?>">
							<div class="tg-icon">
								<?php if ( $img ) : ?>
									<img src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $term->name ); ?>">
								<?php endif; ?>
							</div>
							<div class="tg-title"><?php echo esc_html( $term->name ); ?></div>
						</a>
					</div>
				<?php endforeach; ?>
			<?php else : ?>
				<p><?php esc_html_e( 'No categories yet.', 'courses-system' ); ?></p>
			<?php endif; ?>
		</div>

	</div>
</section>

<?php get_footer();