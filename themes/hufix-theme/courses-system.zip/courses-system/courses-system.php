<?php
/**
 * Plugin Name: Courses System
 * Description: نظام كورسات متكامل (Master + Sessions) مع تكرار تلقائي، دول العالم، استيراد اكسيل، ودعم WPML.
 * Version:     1.0.0
 * Author:      Tasweqa
 * Text Domain: courses-system
 *
 * ملاحظة: لو بتنشر عن طريق Code Snippets، انسخ محتوى كل فايل في سنيبت منفصل
 * بنفس الترتيب اللي تحت. لو بتنشر كـ plugin، سيب الملفات زي ما هي.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CS_VERSION', '1.0.0' );
define( 'CS_PATH', plugin_dir_path( __FILE__ ) );
define( 'CS_URL', plugin_dir_url( __FILE__ ) );

/**
 * ثوابت أساسية للسيستم كله عشان نبعد عن الـ magic strings.
 */
define( 'CS_CPT', 'course' );                 // البوست تايب
define( 'CS_TAX', 'course_category' );        // التاكسونومي (الكاتيجوري)
define( 'CS_META_IS_MASTER', '_cs_is_master' ); // 1 = ماستر كورس (قالب مخفي)
define( 'CS_META_MASTER', '_cs_master' );       // على السيشن: ID الماستر
define( 'CS_META_DATE', '_cs_session_date' );   // على السيشن: تاريخ البداية (Y-m-d)
define( 'CS_META_COUNTRY', '_cs_session_country' ); // على السيشن: كود الدولة

/**
 * تحميل فايلات الفيتشرز.
 * كل فايل = فيتشر واحدة بمسؤولية واحدة.
 */
$cs_files = array(
	'includes/class-cs-countries.php',   // بيانات دول العالم
	'includes/class-cs-cpt.php',         // تسجيل البوست تايب
	'includes/class-cs-taxonomy.php',    // تسجيل الكاتيجوري + صورة الكاتيجوري
	'includes/class-cs-acf.php',         // حقول ACF بالكود
	'includes/class-cs-recurrence.php',  // محرك التكرار + مزامنة + تجديد سنوي
	'includes/class-cs-slider.php',      // تحكم الإسلايدر
	'includes/class-cs-templates.php',   // تحميل تمبليتات الصفحات
	// الباقي هنضيفه في الخطوات الجاية:
	// 'includes/class-cs-listing.php',  // منطق عدم التكرار (الصفحة 2)
	// 'includes/class-cs-import.php',   // رفع الشيت
);

foreach ( $cs_files as $cs_file ) {
	$path = CS_PATH . $cs_file;
	if ( file_exists( $path ) ) {
		require_once $path;
	}
}

/**
 * تفعيل / إلغاء التفعيل: نظّف الـ rewrite rules واجدول الكرون.
 */
register_activation_hook( __FILE__, function () {
	if ( class_exists( 'CS_CPT' ) ) {
		CS_CPT::register();
	}
	if ( class_exists( 'CS_Taxonomy' ) ) {
		CS_Taxonomy::register();
	}
	flush_rewrite_rules();

	// كرون يومي للتجديد السنوي وتنظيف السيشنز القديمة.
	if ( ! wp_next_scheduled( 'cs_daily_maintenance' ) ) {
		wp_schedule_event( time(), 'daily', 'cs_daily_maintenance' );
	}
} );

register_deactivation_hook( __FILE__, function () {
	flush_rewrite_rules();
	wp_clear_scheduled_hook( 'cs_daily_maintenance' );
} );